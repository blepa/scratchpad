USE [msdb]
GO

SET NOCOUNT ON
GO


BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0

IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId_del binary(16)
SELECT @jobId_del = job_id FROM msdb.dbo.sysjobs WHERE (name = N'Monitoring: Event_Deadlock')


IF ( @jobId_del IS NOT NULL )
BEGIN
	PRINT 'Info:  ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Deleting job [Monitoring: Event_Deadlock]...'
	---
	---
	EXEC msdb.dbo.sp_delete_job @jobId_del 
	---
	---
	PRINT '(-)    ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Deleted job [Monitoring: Event_Deadlock].'
END

PRINT 'Info:  ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Adding job [Monitoring: Event_Deadlock]...'
---
---
DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Monitoring: Event_Deadlock', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
---
---
PRINT '(+)    ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Added job [Monitoring: Event_Deadlock].'

PRINT 'Info:  ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Adding step [AddNewDeadlockGraphs] to job [Monitoring: Event_Deadlock]...'
---
---
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'AddNewDeadlockGraphs', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE Monitoring
GO

EXEC [dbo].[spEvDeadlockAddNewDeadlockGraphs]
GO', 
		@database_name=N'Monitoring', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
---
---
PRINT '(+)    ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Added step to [AddNewDeadlockGraphs] job [Monitoring: Event_Deadlock].'

PRINT 'Info:  ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Adding step [AddNewProcess] to job [Monitoring: Event_Deadlock]...'
---
---
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'AddNewProcess', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE Monitoring
GO

EXEC [dbo].[spEvDeadlockProcessListAddNewProcess]
GO
', 
		@database_name=N'Monitoring', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
---
---
PRINT '(+)    ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Added step to [AddNewProcess] job [Monitoring: Event_Deadlock].'

PRINT 'Info:  ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Adding step [AddNewResource] to job [Monitoring: Event_Deadlock]...'
---
---
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'AddNewResource', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE Monitoring
GO

EXEC [dbo].[spEvDeadlockProcessListAddNewResource]
GO', 
		@database_name=N'Monitoring', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
---
---
PRINT '(+)    ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Added step to [AddNewResource] job [Monitoring: Event_Deadlock].'

PRINT 'Info:  ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Adding step [AddNewStack] to job [Monitoring: Event_Deadlock]...'
---
---
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'AddNewStack', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE Monitoring
GO


EXEC [dbo].[spEvDeadlockProcessListExecutionStackAddNewStack]
GO', 
		@database_name=N'Monitoring', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
PRINT '(+)    ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Added step [AddNewStack] to job [Monitoring: Event_Deadlock].'
---
---


PRINT 'Info:  ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Updating job [Monitoring: Event_Deadlock]...'
---
---
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'every_5_min', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=5, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20170109, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'4fde0418-2fdb-4423-8ab2-921a7365b6b9'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
---
---
PRINT '(+)    ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Updated job [Monitoring: Event_Deadlock].'

PRINT 'Info:  ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Adding job [Monitoring: Event_Deadlock] to server...'
---
---
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
---
---
PRINT '(+)    ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Added job [Monitoring: Event_Deadlock] to server.'
COMMIT TRANSACTION
GOTO EndSave

QuitWithRollback:	
	PRINT 'Error:  ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Error - ROLLBACK TRANSACTION'
	---
	---
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
	--
	--

EndSave:		
GO

SET NOCOUNT OFF
GO