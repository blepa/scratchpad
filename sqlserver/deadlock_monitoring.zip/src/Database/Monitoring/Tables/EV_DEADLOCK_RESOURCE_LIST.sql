USE Monitoring
GO

SET NOCOUNT ON
GO

--- 
--- Creating Table
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[dbo].[EV_DEADLOCK_RESOURCE_LIST]') AND OBJECTPROPERTY(id, 'IsUserTable') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating table [dbo].[EV_DEADLOCK_RESOURCE_LIST]...'
	---
	---
	CREATE TABLE [dbo].[EV_DEADLOCK_RESOURCE_LIST]
	(
		DeadlockResourceListID bigint identity(1,1) not null 
	,	DeadlockID bigint not null		
	,	ResourceType char(20) not null
	,	AssociatedObjectName sysname null
	,	resourceid char(30) not null
	,	fileid int null
	,	pageid bigint null
	,	hobtid bigint null
	,	lockPartition int null
	,	objid int null
	,	subresource varchar(100) null
	,	dbid smallint null	
	,	objectname varchar(1000) null
	,	indexname sysname null
	,	mode char(5) null
	,	associatedObjectId bigint null
	,	WaitType nvarchar(60) null
	,	nodeId int null
	,	CreationDate datetime not null
	)
	---
	---
	PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created table [dbo].[EV_DEADLOCK_RESOURCE_LIST].'
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists table [dbo].[EV_DEADLOCK_RESOURCE_LIST].'
GO

--- 
--- Creating Primary Key
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('PK_EV_DEADLOCK_RESOURCE_LIST_DeadlockResourceListID') AND OBJECTPROPERTY(id, 'IsPrimaryKey') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating Primary Key [PK_EV_DEADLOCK_RESOURCE_LIST_DeadlockResourceListID]...'
	---
	---
	ALTER TABLE [dbo].[EV_DEADLOCK_RESOURCE_LIST]
		ADD CONSTRAINT [PK_EV_DEADLOCK_RESOURCE_LIST_DeadlockResourceListID]
		PRIMARY KEY (DeadlockResourceListID )
	---
	---
	PRINT '(+)    '  + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created Primary Key [PK_EV_DEADLOCK_RESOURCE_LIST_DeadlockResourceListID].'
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists Primary Key [PK_EV_DEADLOCK_RESOURCE_LIST_DeadlockResourceListID].'
GO

--- 
--- Creating Index
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysIndexes WHERE name = 'IX_EV_DEADLOCK_RESOURCE_LIST_DeadlockID')
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating Index [IX_EV_DEADLOCK_RESOURCE_LIST_DeadlockID]...'
	---
	---
	CREATE NONCLUSTERED INDEX IX_EV_DEADLOCK_RESOURCE_LIST_DeadlockID
		ON [dbo].[EV_DEADLOCK_RESOURCE_LIST] ([DeadlockID])	
	---
	---
	PRINT '(+)    '+ CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created Index [IX_EV_DEADLOCK_RESOURCE_LIST_DeadlockID].'
	
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists Index [IX_EV_DEADLOCK_RESOURCE_LIST_DeadlockID].'
GO

--- 
--- Creating Index
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysIndexes WHERE name = 'IX_EV_DEADLOCK_RESOURCE_LIST_resourceid')
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating Index [IX_EV_DEADLOCK_RESOURCE_LIST_resourceid]...'
	---
	---
	CREATE NONCLUSTERED INDEX IX_EV_DEADLOCK_RESOURCE_LIST_resourceid
		ON [dbo].[EV_DEADLOCK_RESOURCE_LIST] ([resourceid])	
	---
	---
	PRINT '(+)    '+ CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created Index [IX_EV_DEADLOCK_RESOURCE_LIST_resourceid].'
	
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists Index [IX_EV_DEADLOCK_RESOURCE_LIST_resourceid].'
GO

--- 
--- Creating Dafault
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[DF_EV_DEADLOCK_RESOURCE_LIST_CreationDate]') AND OBJECTPROPERTY(id, 'IsDefaultCnst') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating Default Constraint Key [DF_EV_DEADLOCK_RESOURCE_LIST_CreationDate]...'
	---
	ALTER TABLE [dbo].[EV_DEADLOCK_RESOURCE_LIST]
		ADD CONSTRAINT [DF_EV_DEADLOCK_RESOURCE_LIST_CreationDate]
		DEFAULT (GETDATE())
		FOR [CreationDate]
	---
	PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created Default Constraint Key [DF_EV_DEADLOCK_RESOURCE_LIST_CreationDate].'
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists Default Constraint Key [DF_EV_DEADLOCK_RESOURCE_LIST_CreationDate].'
GO

SET NOCOUNT OFF
GO