USE Monitoring
GO

SET NOCOUNT ON
GO

--- 
--- Creating Table
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[dbo].[EV_CONFIG]') AND OBJECTPROPERTY(id, 'IsUserTable') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating table [dbo].[EV_CONFIG]...'
	---
	---
	CREATE TABLE [dbo].[EV_CONFIG]
	(
		ConfigID int not null
	,	ConfigKey varchar(100) not null
	,	ConfigValue varchar(max) null
	,	CreationDate datetime not null
	,	CreationUser varchar(100) not null
	,	UpdateDate datetime null
	,	UpdateUser varchar(100) null
	)
	---
	---
	PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created table [dbo].[EV_CONFIG].'
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists table [dbo].[EV_CONFIG].'
GO
--- 
--- Creating Primary Key
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('PK_EV_CONFIG_ConfigID') AND OBJECTPROPERTY(id, 'IsPrimaryKey') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating Primary Key [PK_EV_CONFIG_ConfigID]...'
	---
	---
	ALTER TABLE [dbo].[EV_CONFIG]
		ADD CONSTRAINT [PK_EV_CONFIG_ConfigID]
		PRIMARY KEY (ConfigID ASC)
	---
	---
	PRINT '(+)    '  + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created Primary Key [PK_EV_CONFIG_ConfigID].'
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists Primary Key [PK_EV_CONFIG_ConfigID].'
GO

--- 
--- Creating Unique index
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[UQ_EV_CONFIG_ConfigKey]') AND OBJECTPROPERTY(id, 'IsUniqueCnst') = 1)
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating Unique Key [UQ_EV_CONFIG_ConfigKey]...'
	---
	---
	ALTER TABLE [dbo].[EV_CONFIG]
		ADD CONSTRAINT [UQ_EV_CONFIG_ConfigKey]
		UNIQUE ([ConfigKey])
	---
	---
	PRINT '(+)    '  + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created Unique Key [UQ_EV_CONFIG_ConfigKey].'
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists Unique Key [UQ_EV_CONFIG_ConfigKey]'
GO

--- 
--- Creating Dafault
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[DF_EV_CONFIG_CreationDate]') AND OBJECTPROPERTY(id, 'IsDefaultCnst') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating Default Constraint Key [DF_EV_CONFIG_CreationDate]...'
	---
	ALTER TABLE [dbo].[EV_CONFIG]
		ADD CONSTRAINT [DF_EV_CONFIG_CreationDate]
		DEFAULT (GETDATE())
		FOR [CreationDate]
	---
	PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created Default Constraint Key [DF_EV_CONFIG_CreationDate].'
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists Default Constraint Key [DF_EV_CONFIG_CreationDate].'
GO

IF NOT EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[DF_EV_CONFIG_CreationUser]') AND OBJECTPROPERTY(id, 'IsDefaultCnst') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating Default Constraint Key [DF_EV_CONFIG_CreationUser]...'
	---
	ALTER TABLE [dbo].[EV_CONFIG]
		ADD CONSTRAINT [DF_EV_CONFIG_CreationUser]
		DEFAULT (SUSER_SNAME())
		FOR [CreationUser]
	---
	PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created Default Constraint Key [DF_EV_CONFIG_CreationUser].'
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists Default Constraint Key [DF_EV_CONFIG_CreationUser].'
GO

SET NOCOUNT OFF
GO