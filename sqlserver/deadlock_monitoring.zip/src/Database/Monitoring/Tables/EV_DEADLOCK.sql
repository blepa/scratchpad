USE Monitoring
GO

SET NOCOUNT ON
GO

--- 
--- Creating Table
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[dbo].[EV_DEADLOCK]') AND OBJECTPROPERTY(id, 'IsUserTable') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating table [dbo].[EV_DEADLOCK]...'
	---
	---
	CREATE TABLE [dbo].[EV_DEADLOCK]
	(
		DeadlockID bigint identity(1,1) not null
	,	DeadlockGraph xml not null
	,	RaportTimestamp datetime not null
	,	RaportTimestampLocal datetime not null
	,	ProcessQuantity smallint not null
	,	ExecutionStackQuantity smallint not null
	,	ResourceQuantity smallint not null
	,	CreationDate datetime not null
	)
	---
	---
	PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created table [dbo].[EV_DEADLOCK].'
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists table [dbo].[EV_DEADLOCK].'
GO

--- 
--- Creating Primary Key
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('PK_EV_DEADLOCK_DeadlockID') AND OBJECTPROPERTY(id, 'IsPrimaryKey') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating Primary Key [PK_EV_DEADLOCK_DeadlockID]...'
	---
	---
	ALTER TABLE [dbo].[EV_DEADLOCK]
		ADD CONSTRAINT [PK_EV_DEADLOCK_DeadlockID]
		PRIMARY KEY (DeadlockID ASC)
	---
	---
	PRINT '(+)    '  + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created Primary Key [PK_EV_DEADLOCK_DeadlockID].'
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists Primary Key [PK_EV_DEADLOCK_DeadlockID].'
GO

--- 
--- Creating Index
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysIndexes WHERE name = 'IX_EV_DEADLOCK_RaportTimestampLocal')
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating Index [IX_EV_DEADLOCK_RaportTimestampLocal]...'
	---
	---
	CREATE NONCLUSTERED INDEX IX_EV_DEADLOCK_RaportTimestampLocal
		ON [dbo].[EV_DEADLOCK] ([RaportTimestampLocal])	
	---
	---
	PRINT '(+)    '+ CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created Index [IX_EV_DEADLOCK_RaportTimestampLocal].'
	
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists Index [IX_EV_DEADLOCK_RaportTimestampLocal].'
GO

--- 
--- Creating Dafault
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[DF_EV_DEADLOCK_CreationDate]') AND OBJECTPROPERTY(id, 'IsDefaultCnst') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating Default Constraint Key [DF_EV_DEADLOCK_CreationDate]...'
	---
	ALTER TABLE [dbo].[EV_DEADLOCK]
		ADD CONSTRAINT [DF_EV_DEADLOCK_CreationDate]
		DEFAULT (GETDATE())
		FOR [CreationDate]
	---
	PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created Default Constraint Key [DF_EV_DEADLOCK_CreationDate].'
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists Default Constraint Key [DF_EV_DEADLOCK_CreationDate].'
GO

SET NOCOUNT OFF
GO