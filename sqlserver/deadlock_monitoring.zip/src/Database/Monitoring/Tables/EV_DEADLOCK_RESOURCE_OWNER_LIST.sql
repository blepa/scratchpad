USE Monitoring
GO

SET NOCOUNT ON
GO

--- 
--- Creating Table
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[dbo].[EV_DEADLOCK_RESOURCE_OWNER_LIST]') AND OBJECTPROPERTY(id, 'IsUserTable') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating table [dbo].[EV_DEADLOCK_RESOURCE_OWNER_LIST]...'
	---
	---
	CREATE TABLE [dbo].[EV_DEADLOCK_RESOURCE_OWNER_LIST]
	(
		DeadlockResourceOwnerListID bigint identity(1,1) not null 
	,	DeadlockID bigint not null
	,	DeadlockResourceListID int not null		
	,	ownerid char(50) not null
	,	mode char(5) null
	,	CreationDate datetime not null
	)
	---
	---
	PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created table [dbo].[EV_DEADLOCK_RESOURCE_OWNER_LIST].'
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists table [dbo].[EV_DEADLOCK_RESOURCE_OWNER_LIST].'
GO

--- 
--- Creating Primary Key
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('PK_EV_DEADLOCK_RESOURCE_OWNER_LIST_DeadlockResourceOwnerListID') AND OBJECTPROPERTY(id, 'IsPrimaryKey') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating Primary Key [PK_EV_DEADLOCK_RESOURCE_OWNER_LIST_DeadlockResourceOwnerListID]...'
	---
	---
	ALTER TABLE [dbo].[EV_DEADLOCK_RESOURCE_OWNER_LIST]
		ADD CONSTRAINT [PK_EV_DEADLOCK_RESOURCE_OWNER_LIST_DeadlockResourceOwnerListID]
		PRIMARY KEY (DeadlockResourceOwnerListID )
	---
	---
	PRINT '(+)    '  + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created Primary Key [PK_EV_DEADLOCK_RESOURCE_OWNER_LIST_DeadlockResourceOwnerListID].'
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists Primary Key [PK_EV_DEADLOCK_RESOURCE_OWNER_LIST_DeadlockResourceOwnerListID].'
GO

--- 
--- Creating Index
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysIndexes WHERE name = 'IX_EV_DEADLOCK_RESOURCE_OWNER_LIST_DeadlockID')
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating Index [IX_EV_DEADLOCK_RESOURCE_OWNER_LIST_DeadlockID]...'
	---
	---
	CREATE NONCLUSTERED INDEX IX_EV_DEADLOCK_RESOURCE_OWNER_LIST_DeadlockID
		ON [dbo].[EV_DEADLOCK_RESOURCE_OWNER_LIST] ([DeadlockID])	
	---
	---
	PRINT '(+)    '+ CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created Index [IX_EV_DEADLOCK_RESOURCE_OWNER_LIST_DeadlockID].'
	
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists Index [IX_EV_DEADLOCK_RESOURCE_OWNER_LIST_DeadlockID].'
GO

--- 
--- Creating Index
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysIndexes WHERE name = 'IX_EV_DEADLOCK_RESOURCE_OWNER_LIST_DeadlockResourceListID')
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating Index [IX_EV_DEADLOCK_RESOURCE_OWNER_LIST_DeadlockResourceListID]...'
	---
	---
	CREATE NONCLUSTERED INDEX IX_EV_DEADLOCK_RESOURCE_OWNER_LIST_DeadlockResourceListID
		ON [dbo].[EV_DEADLOCK_RESOURCE_OWNER_LIST] ([DeadlockResourceListID])	
	---
	---
	PRINT '(+)    '+ CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created Index [IX_EV_DEADLOCK_RESOURCE_OWNER_LIST_DeadlockResourceListID].'
	
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists Index [IX_EV_DEADLOCK_RESOURCE_OWNER_LIST_DeadlockResourceListID].'
GO

--- 
--- Creating Dafault
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[DF_EV_DEADLOCK_RESOURCE_OWNER_LIST_CreationDate]') AND OBJECTPROPERTY(id, 'IsDefaultCnst') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating Default Constraint Key [DF_EV_DEADLOCK_RESOURCE_OWNER_LIST_CreationDate]...'
	---
	ALTER TABLE [dbo].[EV_DEADLOCK_RESOURCE_OWNER_LIST]
		ADD CONSTRAINT [DF_EV_DEADLOCK_RESOURCE_OWNER_LIST_CreationDate]
		DEFAULT (GETDATE())
		FOR [CreationDate]
	---
	PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created Default Constraint Key [DF_EV_DEADLOCK_RESOURCE_OWNER_LIST_CreationDate].'
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists Default Constraint Key [DF_EV_DEADLOCK_RESOURCE_OWNER_LIST_CreationDate].'
GO

SET NOCOUNT OFF
GO