USE Monitoring
GO

SET NOCOUNT ON
GO

--- 
--- Creating Table
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[dbo].[EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK]') AND OBJECTPROPERTY(id, 'IsUserTable') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating table [dbo].[DEADLOCK_PROCESS_LIST]...'
	---
	---
	CREATE TABLE [dbo].[EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK]
	(
		DeadlockProcessListExecutionStackID bigint identity(1,1) not null
	,	DeadlockID bigint not null
	,	DeadlockProcessListID bigint not null
	,	procname varchar(200) null
	,	line int null
	,	stmtstart int null
	,	stmtend int null
	,	sql_handle varbinary(64) null
	,	plan_handle varbinary(64) null
	,	dbid smallint null
	,	dbname sysname null 
	,	objectid int  null
	,	objectname sysname null
	,	query_plan xml null	
	,	sql_text nvarchar(max) null
	,	stmt_plan xml null	
	,	stmt_text nvarchar(max) null
	--
	--
	,	plan_execution_count bigint null
	,	plan_generation_num bigint null
	,	plan_creation_time datetime null
	,	plan_last_execution_time datetime null	
	,	CreationDate datetime not null
	)
	---
	---
	PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created table [dbo].[DEADLOCK_PROCESS_LIST].'
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists table [dbo].[DEADLOCK_PROCESS_LIST].'
GO

--- 
--- Creating Primary Key
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('PK_EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK_DeadlockProcessListExecutionStackID') AND OBJECTPROPERTY(id, 'IsPrimaryKey') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating Primary Key [PK_EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK_DeadlockProcessListExecutionStackID]...'
	---
	---
	ALTER TABLE [dbo].[EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK]
		ADD CONSTRAINT [PK_EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK_DeadlockProcessListExecutionStackID]
		PRIMARY KEY (DeadlockProcessListExecutionStackID ASC)
	---
	---
	PRINT '(+)    '  + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created Primary Key [PK_EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK_DeadlockProcessListExecutionStackID].'
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists Primary Key [PK_EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK_DeadlockProcessListExecutionStackID].'
GO

--- 
--- Creating Index
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysIndexes WHERE name = 'IX_EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK_DeadlockProcessListID')
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating Index [IX_EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK_DeadlockProcessListID]...'
	---
	---
	CREATE NONCLUSTERED INDEX IX_EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK_DeadlockProcessListID
		ON [dbo].[EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK] ([DeadlockProcessListID])	
	---
	---
	PRINT '(+)    '+ CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created Index [IX_EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK_DeadlockProcessListID].'
	
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists Index [IX_EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK_DeadlockProcessListID].'
GO

--- 
--- Creating Index
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysIndexes WHERE name = 'IX_EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK_DeadlockID')
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating Index [IX_EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK_DeadlockID]...'
	---
	---
	CREATE NONCLUSTERED INDEX IX_EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK_DeadlockID
		ON [dbo].[EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK] ([DeadlockID])	
	---
	---
	PRINT '(+)    '+ CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created Index [IX_EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK_DeadlockID].'
	
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists Index [IX_EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK_DeadlockID].'
GO

--- 
--- Creating Dafault
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[IX_EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK_CreationDate]') AND OBJECTPROPERTY(id, 'IsDefaultCnst') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating Default Constraint Key [IX_EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK_CreationDate]...'
	---
	ALTER TABLE [dbo].[EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK]
		ADD CONSTRAINT [IX_EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK_CreationDate]
		DEFAULT (GETDATE())
		FOR [CreationDate]
	---
	PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created Default Constraint Key [IX_EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK_CreationDate].'
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists Default Constraint Key [IX_EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK_CreationDate].'
GO

SET NOCOUNT OFF
GO