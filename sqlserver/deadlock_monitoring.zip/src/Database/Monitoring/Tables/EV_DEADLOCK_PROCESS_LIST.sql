USE Monitoring
GO

SET NOCOUNT ON
GO

--- 
--- Creating Table
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[dbo].[EV_DEADLOCK_PROCESS_LIST]') AND OBJECTPROPERTY(id, 'IsUserTable') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating table [dbo].[EV_DEADLOCK_PROCESS_LIST]...'
	---
	---
	CREATE TABLE [dbo].[EV_DEADLOCK_PROCESS_LIST]
	(
		DeadlockProcessListID bigint identity(1,1) not null 
	,	DeadlockID bigint not null	
	,	IsVictim bit not null
	,	id char(30) not null
	,	inputbuf varchar(max) null	
	,	taskpriority int null
	,	logused int null
	,	waitresource varchar(1000) null
	,	waittime bigint null
	,	ownerId bigint null
	,	transactionname varchar(32) null
	,	lasttranstarted datetime null
	,	XDES varchar(100) null
	,	lockMode varchar(10) null
	,	schedulerid bigint null
	,	kpid bigint null
	,	status varchar(100) null
	,	spid smallint null
	,	sbid bigint null
	,	ecid bigint null
	,	priority int null
	,	trancount smallint null
	,	lastbatchstarted datetime null
	,	lastbatchcompleted datetime null
	,	clientapp varchar(max) null
	,	hostname varchar(4000) null
	,	hostpid bigint null
	,	loginname varchar(1000) null
	,	isolationlevel varchar(200) null
	,	xactid bigint null
	,	currentdb smallint null
	,	lockTimeout varchar(20) null
	,	clientoption1 varchar(1000) null
	,	clientoption2 varchar(1000) null
	,	CreationDate datetime not null
	)
	---
	---
	PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created table [dbo].[EV_DEADLOCK_PROCESS_LIST].'
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists table [dbo].[EV_DEADLOCK_PROCESS_LIST].'
GO

--- 
--- Creating Primary Key
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('PK_EV_DEADLOCK_PROCESS_LIST_DeadlockProcessListID') AND OBJECTPROPERTY(id, 'IsPrimaryKey') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating Primary Key [PK_EV_DEADLOCK_PROCESS_LIST_DeadlockProcessListID]...'
	---
	---
	ALTER TABLE [dbo].[EV_DEADLOCK_PROCESS_LIST]
		ADD CONSTRAINT [PK_EV_DEADLOCK_PROCESS_LIST_DeadlockProcessListID]
		PRIMARY KEY (DeadlockProcessListID ASC)
	---
	---
	PRINT '(+)    '  + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created Primary Key [PK_EV_DEADLOCK_PROCESS_LIST_DeadlockProcessListID].'
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists Primary Key [PK_EV_DEADLOCK_PROCESS_LIST_DeadlockProcessListID].'
GO

--- 
--- Creating Index
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysIndexes WHERE name = 'IX_EV_DEADLOCK_PROCESS_LIST_DeadlockID')
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating Index [IX_EV_DEADLOCK_PROCESS_LIST_DeadlockID]...'
	---
	---
	CREATE NONCLUSTERED INDEX IX_EV_DEADLOCK_PROCESS_LIST_DeadlockID
		ON [dbo].[EV_DEADLOCK_PROCESS_LIST] ([DeadlockID])	
	---
	---
	PRINT '(+)    '+ CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created Index [IX_EV_DEADLOCK_PROCESS_LIST_DeadlockID].'
	
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists Index [IX_EV_DEADLOCK_PROCESS_LIST_DeadlockID].'
GO

--- 
--- Creating Dafault
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[DF_EV_DEADLOCK_PROCESS_LIST_IsVictim]') AND OBJECTPROPERTY(id, 'IsDefaultCnst') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating Default Constraint Key [DF_EV_DEADLOCK_PROCESS_LIST_IsVictim]...'
	---
	ALTER TABLE [dbo].[EV_DEADLOCK_PROCESS_LIST]
		ADD CONSTRAINT [DF_EV_DEADLOCK_PROCESS_LIST_IsVictim]
		DEFAULT (0)
		FOR [IsVictim]
	---
	PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created Default Constraint Key [DF_EV_DEADLOCK_PROCESS_LIST_IsVictim].'
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists Default Constraint Key [DF_EV_DEADLOCK_PROCESS_LIST_IsVictim].'
GO

--- 
--- Creating Dafault
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[DF_EV_DEADLOCK_PROCESS_LIST_CreationDate]') AND OBJECTPROPERTY(id, 'IsDefaultCnst') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating Default Constraint Key [DF_EV_DEADLOCK_PROCESS_LIST_CreationDate]...'
	---
	ALTER TABLE [dbo].[EV_DEADLOCK_PROCESS_LIST]
		ADD CONSTRAINT [DF_EV_DEADLOCK_PROCESS_LIST_CreationDate]
		DEFAULT (GETDATE())
		FOR [CreationDate]
	---
	PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created Default Constraint Key [DF_EV_DEADLOCK_PROCESS_LIST_CreationDate].'
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists Default Constraint Key [DF_EV_DEADLOCK_PROCESS_LIST_CreationDate].'
GO

SET NOCOUNT OFF
GO