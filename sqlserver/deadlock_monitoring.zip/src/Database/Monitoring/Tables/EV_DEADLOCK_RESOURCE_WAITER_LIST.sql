USE Monitoring
GO

SET NOCOUNT ON
GO

--- 
--- Creating Table
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[dbo].[EV_DEADLOCK_RESOURCE_WAITER_LIST]') AND OBJECTPROPERTY(id, 'IsUserTable') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating table [dbo].[EV_DEADLOCK_RESOURCE_WAITER_LIST]...'
	---
	---
	CREATE TABLE [dbo].[EV_DEADLOCK_RESOURCE_WAITER_LIST]
	(
		DeadlockResourceWaiterListID bigint identity(1,1) not null 
	,	DeadlockID  bigint not null
	,	DeadlockResourceListID int not null		
	,	waiterid char(50) not null
	,	mode char(5) null
	,	requestType varchar(100) null
	,	CreationDate datetime not null
	)
	---
	---
	PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created table [dbo].[EV_DEADLOCK_RESOURCE_WAITER_LIST].'
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists table [dbo].[EV_DEADLOCK_RESOURCE_WAITER_LIST].'
GO

--- 
--- Creating Primary Key
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('PK_EV_DEADLOCK_RESOURCE_WAITER_LIST_DeadlockID') AND OBJECTPROPERTY(id, 'IsPrimaryKey') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating Primary Key [PK_EV_DEADLOCK_RESOURCE_WAITER_LIST_DeadlockID]...'
	---
	---
	ALTER TABLE [dbo].[EV_DEADLOCK_RESOURCE_WAITER_LIST]
		ADD CONSTRAINT [PK_EV_DEADLOCK_RESOURCE_WAITER_LIST_DeadlockID]
		PRIMARY KEY (DeadlockResourceWaiterListID )
	---
	---
	PRINT '(+)    '  + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created Primary Key [PK_EV_DEADLOCK_RESOURCE_WAITER_LIST_DeadlockID].'
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists Primary Key [PK_EV_DEADLOCK_RESOURCE_WAITER_LIST_DeadlockID].'
GO

--- 
--- Creating Index
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysIndexes WHERE name = 'IX_EV_DEADLOCK_RESOURCE_WAITER_LIST_DeadlockResourceListID')
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating Index [IX_EV_DEADLOCK_RESOURCE_WAITER_LIST_DeadlockResourceListID]...'
	---
	---
	CREATE NONCLUSTERED INDEX IX_EV_DEADLOCK_RESOURCE_WAITER_LIST_DeadlockResourceListID
		ON [dbo].[EV_DEADLOCK_RESOURCE_WAITER_LIST] ([DeadlockResourceListID])	
	---
	---
	PRINT '(+)    '+ CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created Index [IX_EV_DEADLOCK_RESOURCE_WAITER_LIST_DeadlockResourceListID].'
	
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists Index [IX_EV_DEADLOCK_RESOURCE_WAITER_LIST_DeadlockResourceListID].'
GO

--- 
--- Creating Index
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysIndexes WHERE name = 'IX_EV_DEADLOCK_RESOURCE_WAITER_LIST_waiterid')
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating Index [IX_EV_DEADLOCK_RESOURCE_WAITER_LIST_waiterid]...'
	---
	---
	CREATE NONCLUSTERED INDEX IX_EV_DEADLOCK_RESOURCE_WAITER_LIST_waiterid
		ON [dbo].[EV_DEADLOCK_RESOURCE_WAITER_LIST] ([waiterid])	
	---
	---
	PRINT '(+)    '+ CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created Index [IX_EV_DEADLOCK_RESOURCE_WAITER_LIST_waiterid].'
	
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists Index [IX_EV_DEADLOCK_RESOURCE_WAITER_LIST_waiterid].'
GO

--- 
--- Creating Dafault
---
IF NOT EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[DF_EV_DEADLOCK_RESOURCE_WAITER_LIST_CreationDate]') AND OBJECTPROPERTY(id, 'IsDefaultCnst') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating Default Constraint Key [DF_EV_DEADLOCK_RESOURCE_WAITER_LIST_CreationDate]...'
	---
	ALTER TABLE [dbo].[EV_DEADLOCK_RESOURCE_WAITER_LIST]
		ADD CONSTRAINT [DF_EV_DEADLOCK_RESOURCE_WAITER_LIST_CreationDate]
		DEFAULT (GETDATE())
		FOR [CreationDate]
	---
	PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created Default Constraint Key [DF_EV_DEADLOCK_RESOURCE_WAITER_LIST_CreationDate].'
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists Default Constraint Key [DF_EV_DEADLOCK_RESOURCE_WAITER_LIST_CreationDate].'
GO

SET NOCOUNT OFF
GO