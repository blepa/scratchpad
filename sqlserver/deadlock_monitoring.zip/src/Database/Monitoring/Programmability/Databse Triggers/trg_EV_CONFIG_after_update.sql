USE Monitoring
GO

SET NOCOUNT ON
GO

IF EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[dbo].[trg_EV_CONFIG_after_update]') AND OBJECTPROPERTY(id, 'IsTrigger') = 1)  
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Droping Trigger [dbo].[trg_EV_CONFIG_after_update]...'
	---
	---
	DROP TRIGGER [dbo].[trg_EV_CONFIG_after_update]
	---
	---
	PRINT '(-)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Droped Trigger [dbo].[trg_EV_CONFIG_after_update].'
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Not exists Trigger [dbo].[trg_EV_CONFIG_after_update]...'
GO

PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating Trigger [dbo].[trg_EV_CONFIG_after_update]...'
---
---
GO
CREATE TRIGGER [dbo].[trg_EV_CONFIG_after_update]
ON [dbo].[EV_CONFIG]
AFTER UPDATE
AS 
BEGIn
	UPDATE	EC
	SET		EC.UpdateDate = GETDATE()
		,	EC.UpdateUser = SUSER_SNAME()
	FROM	dbo.EV_CONFIG EC
			JOIN inserted i ON EC.ConfigID = i.ConfigID
END
GO
---
---
PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created Trigger [dbo].[trg_EV_CONFIG_after_update].'
GO

SET NOCOUNT OFF
GO
