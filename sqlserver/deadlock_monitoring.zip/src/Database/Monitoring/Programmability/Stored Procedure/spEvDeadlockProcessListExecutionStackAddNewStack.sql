USE Monitoring
GO

SET NOCOUNT ON
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--- 
--- Droping Procedure
---
IF EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[dbo].[spEvDeadlockProcessListExecutionStackAddNewStack]') AND OBJECTPROPERTY(id, 'IsProcedure') = 1)
BEGIN
	PRINT 'Info:  ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Dropping procedure [dbo].[spEvDeadlockProcessListExecutionStackAddNewStack]...'
	---
	---
	DROP  PROCEDURE [dbo].[spEvDeadlockProcessListExecutionStackAddNewStack]
	---
	---
	PRINT '(-)    ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Droped procedure [dbo].[spEvDeadlockProcessListExecutionStackAddNewStack].'
END
GO 

--- 
--- Creating Procedure
---
PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Creating procedure [dbo].[spEvDeadlockProcessListExecutionStackAddNewStack]...'
GO
CREATE Procedure [dbo].[spEvDeadlockProcessListExecutionStackAddNewStack]
AS
BEGIN
	SET NOCOUNT ON
	SET XACT_ABORT ON 

	--DECLARE @DebugDate DATETIME

	DECLARE @vDeadlockID INT
	DECLARE @vSqlStatement INT
	DECLARE @vDeadlockGraph XML

	DECLARE @tDeadlockWithoutProcess TABLE
	(
		DeadlockID bigint NOT NULL
	,	DeadlockGraph xml NOT NULL	
	,	IsProcessed bit NOT NULL	
	)
	
	CREATE TABLE #deadlock_graph_info
	(
		IdInfo int identity(1,1) NOT NULL
	,	DeadlockID bigint NOT NULL
	,	DeadlockProcessListID bigint NULL
	,	id char(50) COLLATE DATABASE_DEFAULT NOT NULL
	,	procname varchar(200) NULL
	,	line int NULL
	,	stmtstart int NULL
	,	stmtend	int NULL
	,	sqlhandle varbinary(64) NOT NULL
	,	planhandle varbinary(64) NULL
	,	refcounts int NULL
	,	usecounts int NULL
	,	size_in_bytes int NULL
	,	cacheobjtype nvarchar(34) NULL
	,	objtype nvarchar(16) NULL	
	,	dbid smallint NULL
	,	dbname sysname NULL
	,	objectid int NULL
	,	objectname sysname NULL
	,	query_plan xml NULL
	,	execution_count bigint NULL
	,	plan_generation_num bigint NULL
	,	plan_execution_count bigint NULL
	,	creation_time datetime NULL
	,	last_execution_time	datetime NULL
	,	sql_text nvarchar(max) NULL
	,	stmt_plan xml NULL
	,	stmt_text nvarchar(max) NULL
	)


	BEGIN TRY		
		---
		--- get deadlock without process records
		--SET @DebugDate = GETDATE()
		INSERT INTO @tDeadlockWithoutProcess
		(
			DeadlockID
		,	DeadlockGraph
		,	IsProcessed		
		)
		SELECT	D.DeadlockID [DeadlockID]
			,	D.DeadlockGraph [DeadlockGraph]
			,	0 [IsProcessed]
		FROM	dbo.EV_DEADLOCK D WITH(NOLOCK)				
		WHERE	D.ExecutionStackQuantity != dbo.fnEvDeadlockGetExecutionStackQuantity(D.DeadlockID)
		--PRINT 'get deadlock without process records: ' +CAST(  DATEDIFF(ms, @DebugDate, GETDATE()) AS VARCHAR(100) )

		---
		--- add new process records for deadlocks one by one
		WHILE EXISTS	(	SELECT	1
							FROM	@tDeadlockWithoutProcess t
							WHERE	t.IsProcessed = 0 
						)
		BEGIN				
			--
			-- get values for process
			--SET @DebugDate = GETDATE()
			SELECT	TOP(1)					
					@vDeadlockID = t.DeadlockID
				,	@vDeadlockGraph = t.DeadlockGraph
			FROM	@tDeadlockWithoutProcess t 
			WHERE	t.IsProcessed = 0
			ORDER	BY t.DeadlockID
			--PRINT 'get values for process: ' +CAST(  DATEDIFF(ms, @DebugDate, GETDATE()) AS VARCHAR(100) )

			---
			--- add new records
			--SET @DebugDate = GETDATE()					
			INSERT INTO #deadlock_graph_info
			(
				DeadlockID
			,	id
			,	procname
			,	line
			,	stmtstart
			,	stmtend
			,	sqlhandle
			)
			SELECT	@vDeadlockID [DeadlockID]
				--,	DPL.DeadlockProcessListID
				,	fes.id
				,	fes.procname
				,	fes.line
				,	fes.stmtstart
				,	fes.stmtend
				,	fes.sqlhandle
			--INTO	#deadlock_graph_info
			FROM	dbo.fnEvDeadlockGraphGetExectuionStack(@vDeadlockGraph) fes					
			--PRINT 'add new records: ' +CAST(  DATEDIFF(ms, @DebugDate, GETDATE()) AS VARCHAR(100) )
					
			---
			--- change records to processed
			UPDATE	t
			SET		t.IsProcessed = 1
			FROM	@tDeadlockWithoutProcess t
			WHERE	t.DeadlockID = @vDeadlockID
		END
		--
		-- getting plan handles
		--SET @DebugDate = GETDATE()	
		UPDATE	gi
		SET		gi.planhandle = dqs.plan_handle
			,	gi.execution_count = dqs.execution_count
			,	gi.plan_generation_num = dqs.plan_generation_num
			,	gi.plan_execution_count = dqs.execution_count
			,	gi.creation_time = dqs.creation_time
			,	gi.last_execution_time = dqs.last_execution_time
		FROM	#deadlock_graph_info gi WITH(TABLOCK)
				INNER JOIN sys.dm_exec_query_stats dqs WITH(NOLOCK) ON dqs.sql_handle = gi.sqlhandle AND dqs.statement_start_offset = gi.stmtstart AND dqs.statement_end_offset = ISNULL(gi.stmtend, -1)
		--PRINT 'getting plan handles: ' + CAST(  DATEDIFF(ms, @DebugDate, GETDATE()) AS VARCHAR(100) )
			
		---
		--- getting query plans info
		--SET @DebugDate = GETDATE()	
		UPDATE	gi
		SET		gi.dbid = dqp.dbid
			,	gi.dbname = DB_NAME(dqp.dbid)
			,	gi.objectid = dqp.objectid
			,	gi.objectname = OBJECT_NAME(dqp.objectid, dqp.dbid)
			,	gi.query_plan = dqp.query_plan
		FROM	#deadlock_graph_info gi WITH(TABLOCK)
				CROSS APPLY  sys.dm_exec_query_plan(gi.planhandle) dqp
		--PRINT 'getting query plans info: ' + CAST(  DATEDIFF(ms, @DebugDate, GETDATE()) AS VARCHAR(100) )

		---
		--- getting sql text 
		--SET @DebugDate = GETDATE()	
		UPDATE	gi
		SET		gi.sql_text = dst.text			
			,	gi.dbid = ISNULL(dst.dbid, gi.dbid)
			,	gi.dbname = ISNULL(DB_NAME(dst.dbid), gi.dbname)
			,	gi.objectid = ISNULL(dst.objectid, gi.objectid)
			,	gi.objectname = ISNULL(OBJECT_NAME(dst.objectid, dst.dbid), gi.objectname)
		FROM	#deadlock_graph_info gi WITH(TABLOCK)
				CROSS APPLY sys.dm_exec_sql_text(gi.sqlhandle) dst
		--PRINT 'getting sql text: ' + CAST(  DATEDIFF(ms, @DebugDate, GETDATE()) AS VARCHAR(100) )

		---
		--- getting stmt text
		--SET @DebugDate = GETDATE()	
		UPDATE	gi
		SET		gi.stmt_plan = dqp.query_plan
			,	gi.stmt_text = 	CASE
									WHEN gi.stmtend IS NOT NULL
									THEN SUBSTRING(gi.sql_text, (gi.stmtstart/2) + 1, ( gi.stmtend - gi.stmtstart) / 2 )
									ELSE SUBSTRING(gi.sql_text, (gi.stmtstart/2) + 1, LEN(gi.sql_text))
								END			
		FROM	#deadlock_graph_info gi WITH(TABLOCK)
				CROSS APPLY sys.dm_exec_text_query_plan(gi.planhandle, gi.stmtstart, ISNULL(gi.stmtend, -1)) dqp 
		--PRINT 'getting stmt text: ' + CAST(  DATEDIFF(ms, @DebugDate, GETDATE()) AS VARCHAR(100) )

		---
		--- getting DeadlockProcessListID
		--SET @DebugDate = GETDATE()	
		UPDATE	gi
		SET		gi.DeadlockProcessListID = EPL.DeadlockProcessListID
		FROM	#deadlock_graph_info gi WITH(TABLOCK)
				INNER JOIN dbo.EV_DEADLOCK_PROCESS_LIST EPL WITH(NOLOCK) ON gi.DeadlockID = EPL.DeadlockID AND gi.id = EPL.id
		--PRINT 'getting DeadlockProcessListID: ' + CAST(  DATEDIFF(ms, @DebugDate, GETDATE()) AS VARCHAR(100) )	

		---
		--- adding data to EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK
		--SET @DebugDate = GETDATE()	
		INSERT INTO dbo.EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK WITH(ROWLOCK,XLOCK)
		(
			DeadlockID
		,	DeadlockProcessListID
		,	procname
		,	line
		,	stmtstart
		,	stmtend
		,	sql_handle
		,	plan_handle
		,	dbid
		,	dbname
		,	objectid
		,	objectname
		,	query_plan
		,	sql_text
		,	stmt_plan
		,	stmt_text
		,	plan_execution_count
		,	plan_generation_num
		,	plan_creation_time
		,	plan_last_execution_time			
		)
		SELECT	gi.DeadlockID 
			,	gi.DeadlockProcessListID
			,	gi.procname
			,	gi.line
			,	gi.stmtstart
			,	gi.stmtend
			,	gi.sqlhandle
			,	gi.planhandle
			,	gi.dbid
			,	gi.dbname
			,	gi.objectid
			,	gi.objectname
			,	gi.query_plan
			,	gi.sql_text
			,	gi.stmt_plan
			,	gi.stmt_text
			,	gi.plan_execution_count
			,	gi.plan_generation_num
			,	gi.creation_time
			,	gi.last_execution_time
		FROM	#deadlock_graph_info gi WITH(NOLOCK)
				LEFT JOIN dbo.EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK ES WITH(NOLOCK) ON gi.DeadlockProcessListID = ES.DeadlockProcessListID
		WHERE	ES.DeadlockProcessListExecutionStackID IS NULL
		--PRINT 'adding data to EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK: ' + CAST(  DATEDIFF(ms, @DebugDate, GETDATE()) AS VARCHAR(100) )

		
	END TRY
	BEGIN CATCH
		SELECT	ERROR_NUMBER() AS ErrorNumber  
			,	ERROR_SEVERITY() AS ErrorSeverity  
			,	ERROR_STATE() AS ErrorState  
			,	ERROR_PROCEDURE() AS ErrorProcedure  
			,	ERROR_LINE() AS ErrorLine  
			,	ERROR_MESSAGE() AS ErrorMessage			
	END CATCH

	RETURN 0	
END
GO

PRINT '(+)    ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Created procedure [dbo].[spEvDeadlockProcessListExecutionStackAddNewStack].'
GO

SET NOCOUNT OFF
GO

