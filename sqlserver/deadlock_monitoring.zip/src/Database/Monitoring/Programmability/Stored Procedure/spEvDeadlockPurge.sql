USE Monitoring
GO

SET NOCOUNT ON
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--- 
--- Droping Procedure
---
IF EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[dbo].[spEvDeadlockPurge]') AND OBJECTPROPERTY(id, 'IsProcedure') = 1)
BEGIN
	PRINT 'Info:  ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Dropping procedure [dbo].[spEvDeadlockPurge]...'
	---
	---
	DROP  PROCEDURE [dbo].[spEvDeadlockPurge]
	---
	---
	PRINT '(-)    ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Droped procedure [dbo].[spEvDeadlockPurge].'
END
GO 

--- 
--- Creating Procedure
---
PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Creating procedure [dbo].[spEvDeadlockPurge]...'
GO
CREATE Procedure [dbo].[spEvDeadlockPurge]
(
	@PurgeReferenceDate DATETIME = NULL
,	@PurgeDelayDay INT = NULL
)
AS
BEGIN
	SET NOCOUNT ON
	SET XACT_ABORT ON 	

	DECLARE @vPurgeReferenceDate DATETIME
	DECLARE @vPurgeDelayDay INT	

	CREATE TABLE #tmpDeadlockDelete
	(
		DeadlockID BIGINT
	)	
	
	BEGIN TRY
		SELECT @vPurgeDelayDay = dbo.fnEvConfigGetPurgeDelayDay(@PurgeDelayDay)
		SELECT @vPurgeReferenceDate = dbo.fnEvConfigGetPurgeDate(@PurgeReferenceDate, @vPurgeDelayDay)

		---
		--- getting dedlock id to delete
		INSERT INTO #tmpDeadlockDelete
		(
			DeadlockID
		)
		SELECT	ED.DeadlockID
		FROM	dbo.EV_DEADLOCK ED WITH(NOLOCK)
		WHERE	ED.RaportTimestampLocal < @vPurgeReferenceDate

		--- 
		--- delete data		
		DELETE	T
		FROM	#tmpDeadlockDelete tmp 
				JOIN dbo.EV_DEADLOCK_RESOURCE_WAITER_LIST T WITH(ROWLOCK,XLOCK) ON tmp.DeadlockID = T.DeadlockID

		DELETE	T
		FROM	#tmpDeadlockDelete tmp 
				JOIN dbo.EV_DEADLOCK_RESOURCE_OWNER_LIST T WITH(ROWLOCK,XLOCK) ON tmp.DeadlockID = T.DeadlockID
			
		DELETE	T
		FROM	#tmpDeadlockDelete tmp 
				JOIN dbo.EV_DEADLOCK_RESOURCE_LIST T WITH(ROWLOCK,XLOCK) ON tmp.DeadlockID = T.DeadlockID

		DELETE	T
		FROM	#tmpDeadlockDelete tmp 
				JOIN dbo.EV_DEADLOCK_PROCESS_LIST_EXECUTION_STACK T WITH(ROWLOCK,XLOCK) ON tmp.DeadlockID = T.DeadlockID

		DELETE	T
		FROM	#tmpDeadlockDelete tmp 
				JOIN dbo.EV_DEADLOCK_PROCESS_LIST T WITH(ROWLOCK,XLOCK) ON tmp.DeadlockID = T.DeadlockID

		DELETE	T
		FROM	#tmpDeadlockDelete tmp 
				JOIN dbo.EV_DEADLOCK T WITH(ROWLOCK,XLOCK) ON tmp.DeadlockID = T.DeadlockID
		
		
	END TRY
	BEGIN CATCH
		SELECT	ERROR_NUMBER() AS ErrorNumber  
			,	ERROR_SEVERITY() AS ErrorSeverity  
			,	ERROR_STATE() AS ErrorState  
			,	ERROR_PROCEDURE() AS ErrorProcedure  
			,	ERROR_LINE() AS ErrorLine  
			,	ERROR_MESSAGE() AS ErrorMessage			
	END CATCH

	RETURN 0	
END
GO

PRINT '(+)    ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Created procedure [dbo].[spEvDeadlockPurge].'
GO

SET NOCOUNT OFF
GO