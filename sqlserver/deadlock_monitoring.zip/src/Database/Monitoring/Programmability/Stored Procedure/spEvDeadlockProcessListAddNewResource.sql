USE Monitoring
GO

SET NOCOUNT ON
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--- 
--- Droping Procedure
---
IF EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[dbo].[spEvDeadlockProcessListAddNewResource]') AND OBJECTPROPERTY(id, 'IsProcedure') = 1)
BEGIN
	PRINT 'Info:  ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Dropping procedure [dbo].[spEvDeadlockProcessListAddNewResource]...'
	---
	---
	DROP  PROCEDURE [dbo].[spEvDeadlockProcessListAddNewResource]
	---
	---
	PRINT '(-)    ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Droped procedure [dbo].[spEvDeadlockProcessListAddNewResource].'
END
GO 

--- 
--- Creating Procedure
---
PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Creating procedure [dbo].[spEvDeadlockProcessListAddNewResource]...'
GO
CREATE Procedure [dbo].[spEvDeadlockProcessListAddNewResource]
AS
BEGIN
	SET NOCOUNT ON
	SET XACT_ABORT ON

	DECLARE @VDeadlockID INT
	DECLARE @vDeadlockGraph XML
	DECLARE @vDeadlockResourceID INT
	DECLARE @vAssociatedObjectName SYSNAME
	DECLARE @vAssociatedObjecCmd VARCHAR(4000)

	DECLARE @tDeadlockWithoutResource TABLE
	(
		DeadlockID int NOT NULL
	,	DeadlockGraph xml NOT NULL
	,	IsProcessed bit NOT NULL
	)

	DECLARE @tDeadlockResource TABLE 
	(
		ID int identity(1,1) NOT NULL
	,	DeadlockResourceListID int NOT NULL
	,	resourceid char(50) NOT NULl
	,	dbid smallint null
	,	associatedObjectId bigint null
	,	IsProcessed bit NOT NULL
	)

	DECLARE @tAssociatedObjectRealId TABLE
	(
		object_id int
	)

	BEGIN TRY
		---
		--- get deadlock without process records
		INSERT INTO @tDeadlockWithoutResource
		(
			DeadlockID
		,	DeadlockGraph
		,	IsProcessed
		)
		SELECT	D.DeadlockID [DeadlockID]
			,	D.DeadlockGraph [DeadlockGraph]
			,	0 [IsProcessed]
		FROM	dbo.EV_DEADLOCK D WITH(NOLOCK)
		WHERE	D.ResourceQuantity != dbo.fnEvDeadlockGetResourceQuantity(D.DeadlockID)		

		---
		--- add new process records for deadlocks one by one
		WHILE EXISTS	(	SELECT	1
							FROM	@tDeadlockWithoutResource t
							WHERE	t.IsProcessed = 0
						)
		BEGIN
			---
			--- get values for process
			SELECT	TOP(1)
					@VDeadlockID = t.DeadlockID
				,	@vDeadlockGraph = t.DeadlockGraph
			FROM	@tDeadlockWithoutResource t 
			WHERE	t.IsProcessed = 0
			ORDER	BY t.DeadlockID

			---
			--- clear table
			DELETE	t
			FROM	@tDeadlockResource t

			---
			--- adding resource list	
			INSERT INTO dbo.EV_DEADLOCK_RESOURCE_LIST WITH(ROWLOCK,XLOCK)
			(
				DeadlockID
			,	ResourceType
			,	AssociatedObjectName
			,	resourceid
			,	fileid
			,	pageid
			,	hobtid
			,	dbid
			,	objectname
			,	indexname
			,	mode
			,	associatedObjectId
			,	WaitType
			,	nodeId
			)
			OUTPUT	inserted.DeadlockResourceListID
				,	inserted.resourceid
				,	inserted.dbid
				,	inserted.associatedObjectId
				,	0
			INTO	@tDeadlockResource		
					(
						DeadlockResourceListID
					,	resourceid
					,	dbid
					,	associatedObjectId
					,	IsProcessed
					)
			SELECT	@VDeadlockID
				,	frl.ResourceType
				,	NULL [AssociatedObjectName]
				,	frl.resourceid
				,	frl.fileid
				,	frl.pageid
				,	frl.hobtid
				,	frl.dbid
				,	frl.objectname
				,	frl.indexname
				,	frl.mode
				,	frl.associatedObjectId
				,	frl.WaitType
				,	frl.nodeId
			FROM	dbo.fnEvDeadlockGraphGetResourceList(@vDeadlockGraph) frl

			---
			--- adding owner list
			INSERT INTO dbo.EV_DEADLOCK_RESOURCE_OWNER_LIST WITH(ROWLOCK,XLOCK)
			(
				DeadlockID
			,	DeadlockResourceListID
			,	ownerid
			,	mode
			)	
			SELECT	@VDeadlockID
				,	t.DeadlockResourceListID
				,	fol.ownerid
				,	fol.mode
			FROM	@tDeadlockResource t
					JOIN dbo.fnEvDeadlockGraphGetResourceOwnerList(@vDeadlockGraph) fol ON t.resourceid = fol.resourceid

			---
			--- adding waiter list
			INSERT INTO dbo.EV_DEADLOCK_RESOURCE_WAITER_LIST WITH(ROWLOCK,xLOCK)
			(
				DeadlockID
			,	DeadlockResourceListID
			,	waiterid
			,	mode
			,	requestType
			)
			SELECT	@VDeadlockID
				,	t.DeadlockResourceListID				
				,	waiterid
				,	mode
				,	requestType
			FROM	@tDeadlockResource t
					JOIN dbo.fnEvDeadlockGraphGetResourceWaiterList(@vDeadlockGraph) fwl ON t.resourceid = fwl.resourceid				

			---
			--- clear table without associatedObjectId
			DELETE	t
			FROM	@tDeadlockResource t
			WHERE	t.associatedObjectId IS NULL

			---
			--- sets AssociatedObjectName
			WHILE EXISTS	(	SELECT	1
								FROM	@tDeadlockResource t
								WHERE	t.IsProcessed = 0
							)
			BEGIN
				---
				--- clean table for real object_id for associate object
				DELETE	t
				FROM	@tAssociatedObjectRealId t

				---
				--- select records for find AssociatedObjectName
				SELECT	TOP(1)
						@vDeadlockResourceID = t.ID
				FROM	@tDeadlockResource t
				WHERE	t.IsProcessed = 0

				---
				--- clean command
				SET @vAssociatedObjecCmd = NULL

				---
				--- create command
				SELECT	@vAssociatedObjecCmd = '
						SELECT	p.object_id
						FROM	' + DB_NAME(t.dbid) + '.sys.partitions p
						WHERE	p.partition_id = ' + CAST(t.associatedObjectId AS varchar(100))
				FROM	@tDeadlockResource t 
				WHERE	t.ID = @vDeadlockResourceID

				---
				--- set AssociatedObjectName
				IF @vAssociatedObjecCmd IS NOT NULL 
				BEGIN
					--
					-- get real object id
					INSERT INTO @tAssociatedObjectRealId
					EXEC(@vAssociatedObjecCmd)
					
					---
					--- set name of associated object
					UPDATE	DRL
					SET		DRL.AssociatedObjectName = OBJECT_SCHEMA_NAME(tao.object_id, tdr.dbid) + '.' + OBJECT_NAME(tao.object_id, tdr.dbid)
					FROM	@tDeadlockResource tdr
							JOIN @tAssociatedObjectRealId tao ON 1 = 1
							JOIN dbo.EV_DEADLOCK_RESOURCE_LIST DRL WITH(ROWLOCK,XLOCK) ON tdr.DeadlockResourceListID = DRL.DeadlockResourceListID
					WHERE	tdr.Id = @vDeadlockResourceID							
				END

				---
				--- change records to processed
				UPDATE	t
				SET		t.IsProcessed = 1
				FROM	@tDeadlockResource t
				WHERE	t.ID = @vDeadlockResourceID

			END
						

			---
			--- change records to processed
			UPDATE	t
			SET		t.IsProcessed = 1
			FROM	@tDeadlockWithoutResource t 
			WHERE	t.DeadlockID = @VDeadlockID
		END

	END TRY
	BEGIN CATCH
		SELECT	ERROR_NUMBER() AS ErrorNumber  
			,	ERROR_SEVERITY() AS ErrorSeverity  
			,	ERROR_STATE() AS ErrorState  
			,	ERROR_PROCEDURE() AS ErrorProcedure  
			,	ERROR_LINE() AS ErrorLine  
			,	ERROR_MESSAGE() AS ErrorMessage			
	END CATCH

	RETURN 0	
END
GO

PRINT '(+)    ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Created procedure [dbo].[spEvDeadlockProcessListAddNewResource].'
GO

SET NOCOUNT OFF
GO
