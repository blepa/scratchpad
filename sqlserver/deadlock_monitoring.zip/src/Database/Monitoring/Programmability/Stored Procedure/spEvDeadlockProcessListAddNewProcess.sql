USE Monitoring
GO

SET NOCOUNT ON
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--- 
--- Droping Procedure
---
IF EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[dbo].[spEvDeadlockProcessListAddNewProcess]') AND OBJECTPROPERTY(id, 'IsProcedure') = 1)
BEGIN
	PRINT 'Info:  ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Dropping procedure [dbo].[spEvDeadlockProcessListAddNewProcess]...'
	---
	---
	DROP  PROCEDURE [dbo].[spEvDeadlockProcessListAddNewProcess]
	---
	---
	PRINT '(-)    ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Droped procedure [dbo].[spEvDeadlockProcessListAddNewProcess].'
END
GO 

--- 
--- Creating Procedure
---
PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Creating procedure [dbo].[spEvDeadlockProcessListAddNewProcess]...'
GO
CREATE Procedure [dbo].[spEvDeadlockProcessListAddNewProcess]
AS
BEGIN
	SET NOCOUNT ON
	SET XACT_ABORT ON 

	DECLARE @VDeadlockID INT
	DECLARE @vDeadlockGraph XML
	DECLARE @tDeadlockWithoutProcess TABLE
	(
		DeadlockID INT NOT NULL
	,	DeadlockGraph XML NOT NULL
	,	IsProcessed BIT NOT NULL
	)

	BEGIN TRY
		---
		--- get deadlock without process records
		INSERT INTO @tDeadlockWithoutProcess
		(
			DeadlockID
		,	DeadlockGraph
		,	IsProcessed
		)
		SELECT	D.DeadlockID [DeadlockID]
			,	D.DeadlockGraph [DeadlockGraph]
			,	0 [IsProcessed]
		FROM	dbo.EV_DEADLOCK D WITH(NOLOCK)				
		WHERE	D.ProcessQuantity != dbo.fnEvDeadlockGetProcessQuantity(D.DeadlockID)

		---
		--- add new process records for deadlocks one by one
		WHILE EXISTS	(	SELECT	1
							FROM	@tDeadlockWithoutProcess t
							WHERE	t.IsProcessed = 0
						)
		BEGIN
			--
			-- get values for process
			SELECT	TOP(1)
					@VDeadlockID = t.DeadlockID
				,	@vDeadlockGraph = t.DeadlockGraph
			FROM	@tDeadlockWithoutProcess t 
			WHERE	t.IsProcessed = 0
			ORDER	BY t.DeadlockID


			---
			--- add new records
			INSERT INTO dbo.EV_DEADLOCK_PROCESS_LIST WITH(ROWLOCK,XLOCK)
			(
				DeadlockID
			,	IsVictim
			,	id
			,	inputbuf
			,	taskpriority
			,	logused
			,	waitresource
			,	waittime
			,	ownerId
			,	transactionname
			,	lasttranstarted
			,	XDES
			,	lockMode
			,	schedulerid
			,	kpid
			,	status
			,	spid
			,	sbid
			,	ecid
			,	priority
			,	trancount
			,	lastbatchstarted
			,	lastbatchcompleted
			,	clientapp
			,	hostname
			,	hostpid
			,	loginname
			,	isolationlevel
			,	xactid
			,	currentdb
			,	lockTimeout
			,	clientoption1
			,	clientoption2			
			)
			SELECT	@VDeadlockID
				,	fpl.IsVictim
				,	fpl.id
				,	fpl.inputbuf
				,	fpl.taskpriority
				,	fpl.logused
				,	fpl.waitresource
				,	fpl.waittime
				,	fpl.ownerId
				,	fpl.transactionname
				,	fpl.lasttranstarted
				,	fpl.XDES
				,	fpl.lockMode
				,	fpl.schedulerid
				,	fpl.kpid
				,	fpl.status
				,	fpl.spid
				,	fpl.sbid
				,	fpl.ecid
				,	fpl.priority
				,	fpl.trancount
				,	fpl.lastbatchstarted
				,	fpl.lastbatchcompleted
				,	fpl.clientapp
				,	fpl.hostname
				,	fpl.hostpid
				,	fpl.loginname
				,	fpl.isolationlevel
				,	fpl.xactid
				,	fpl.currentdb
				,	fpl.lockTimeout
				,	fpl.clientoption1
				,	fpl.clientoption2				
			FROM	dbo.fnEvDeadlockGraphGetProcessList(@vDeadlockGraph) fpl
			WHERE	NOT EXISTS ( SELECT 1 FROM dbo.EV_DEADLOCK_PROCESS_LIST PL WHERE PL.DeadlockID = @VDeadlockID AND PL.id = fpl.id)

			---
			--- change records to processed
			UPDATE	t
			SET		t.IsProcessed = 1
			FROM	@tDeadlockWithoutProcess t 
			WHERE	t.DeadlockID = @VDeadlockID
		END

	END TRY
	BEGIN CATCH
		SELECT	ERROR_NUMBER() AS ErrorNumber  
			,	ERROR_SEVERITY() AS ErrorSeverity  
			,	ERROR_STATE() AS ErrorState  
			,	ERROR_PROCEDURE() AS ErrorProcedure  
			,	ERROR_LINE() AS ErrorLine  
			,	ERROR_MESSAGE() AS ErrorMessage			
	END CATCH

	RETURN 0	
END
GO

PRINT '(+)    ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Created procedure [dbo].[spEvDeadlockProcessListAddNewProcess].'
GO

SET NOCOUNT OFF
GO
