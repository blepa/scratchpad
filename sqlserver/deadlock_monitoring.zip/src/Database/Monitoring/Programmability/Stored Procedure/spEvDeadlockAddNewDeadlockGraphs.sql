USE Monitoring
GO

SET NOCOUNT ON
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--- 
--- Droping Procedure
---
IF EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[dbo].[spEvDeadlockAddNewDeadlockGraphs]') AND OBJECTPROPERTY(id, 'IsProcedure') = 1)
BEGIN
	PRINT 'Info:  ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Dropping procedure [dbo].[spEvDeadlockAddNewDeadlockGraphs]...'
	---
	---
	DROP  PROCEDURE [dbo].[spEvDeadlockAddNewDeadlockGraphs]
	---
	---
	PRINT '(-)    ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Droped procedure [dbo].[spEvDeadlockAddNewDeadlockGraphs].'
END
GO 

--- 
--- Creating Procedure
---
PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Creating procedure [dbo].[spEvDeadlockAddNewDeadlockGraphs]...'
GO
CREATE Procedure [dbo].[spEvDeadlockAddNewDeadlockGraphs]
AS
BEGIN
	SET NOCOUNT ON
	SET XACT_ABORT ON 

	DECLARE @vRaportTimestamp DATETIME

	BEGIN TRY

		---
		--- get date of last inserted deadlock graphs
		SELECT	TOP(1)
				@vRaportTimestamp = D.RaportTimestamp
		FROM	dbo.EV_DEADLOCK D WITH(NOLOCK)
		ORDER	BY D.RaportTimestampLocal DESC

		---
		--- if not exists records on EV_DEADLOCK then set on defualt purge date
		SELECT	@vRaportTimestamp = ISNULL(@vRaportTimestamp, dbo.fnEvConfigGetPurgeDate(null, dbo.fnEvConfigGetPurgeDelayDay(null)))

		---
		--- insert new deadlock graphs to table
		INSERT INTO dbo.EV_DEADLOCK WITH(ROWLOCK,XLOCK)
		(
			DeadlockGraph
		,	RaportTimestamp
		,	RaportTimestampLocal
		,	ProcessQuantity
		,	ExecutionStackQuantity
		,	ResourceQuantity
		)
		SELECT	fdg.DeadlockGraph [DeadlockGraph]
			,	fdg.RaportTimestamp [RaportTimestamp]
			,	fdg.RaportTimestampLocal [RaportTimestampLocal]
			,	dbo.fnEvDeadlockGraphGetProcessQuantity(fdg.DeadlockGraph) [ProcessQuantity]
			,	dbo.fnEvDeadlockGraphGetExecutionStackQuantity(fdg.DeadlockGraph) [ExecutionStackQuantity]
			,	dbo.fnEvDeadlockGraphGetResourceQuantity(fdg.DeadlockGraph) [ResourceQuantity]
		FROM	dbo.fnEvDeadlockRaportGetDeadlockGraphs(@vRaportTimestamp) fdg
		

	END TRY
	BEGIN CATCH
		SELECT	ERROR_NUMBER() AS ErrorNumber  
			,	ERROR_SEVERITY() AS ErrorSeverity  
			,	ERROR_STATE() AS ErrorState  
			,	ERROR_PROCEDURE() AS ErrorProcedure  
			,	ERROR_LINE() AS ErrorLine  
			,	ERROR_MESSAGE() AS ErrorMessage			
	END CATCH

	RETURN 0	
END
GO

PRINT '(+)    ' +  CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() + ' - Created procedure [dbo].[spEvDeadlockAddNewDeadlockGraphs].'
GO

SET NOCOUNT OFF
GO
