USE Monitoring
GO

SET NOCOUNT ON
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--- 
--- Droping Table Function
---
IF EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[dbo].[fnEvDeadlockGraphGetExectuionStack]') AND OBJECTPROPERTY(id, 'IsInlineFunction') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Droping function [dbo].[fnEvDeadlockGraphGetExectuionStack]...'
	---
	---
	DROP FUNCTION [dbo].[fnEvDeadlockGraphGetExectuionStack]
	---
	---
	PRINT '(-)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Droped function [dbo].[fnEvDeadlockGraphGetExectuionStack].'
END
GO
--- 
--- Creating Table Function
---
PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating function [dbo].[fnEvDeadlockGraphGetExectuionStack]...'
GO
---
---
CREATE FUNCTION [dbo].[fnEvDeadlockGraphGetExectuionStack]
(
	@DeadlockGraph XML
)
RETURNS TABLE
AS
RETURN
(
	---
	--- Get process list from deadlock graph xml
	SELECT	t1.process.value('@id', 'char(50)') [id]		
		,	t3.frame.value('@procname', 'varchar(200)') [procname]
		,	t3.frame.value('@line', 'int') [line]
		,	t3.frame.value('@stmtstart', 'int') [stmtstart]
		,	t3.frame.value('@stmtend', 'int') [stmtend]
		,	CONVERT(varbinary(64), t3.frame.value('@sqlhandle', 'varchar(max)'), 1) [sqlhandle]
	FROM	@DeadlockGraph.nodes('/deadlock/process-list') t(deadlockProcessList)			
			CROSS APPLY t.deadlockProcessList.nodes('./process') t1(process)			
			CROSS APPLY t1.process.nodes('./executionStack') t2(executionStack)
			CROSS APPLY t2.executionStack.nodes('./frame') t3(frame)
)	
GO
---
---
PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created function [dbo].[fnEvDeadlockGraphGetExectuionStack].'
GO

SET NOCOUNT OFF
GO
