USE Monitoring
GO

SET NOCOUNT ON
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--- 
--- Droping Table Function
---
IF EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[dbo].[fnEvDeadlockGraphGetResourceWaiterList]') AND OBJECTPROPERTY(id, 'IsInlineFunction') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Droping function [dbo].[fnEvDeadlockGraphGetResourceWaiterList]...'
	---
	---
	DROP FUNCTION [dbo].[fnEvDeadlockGraphGetResourceWaiterList]
	---
	---
	PRINT '(-)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Droped function [dbo].[fnEvDeadlockGraphGetResourceWaiterList].'
END
GO
--- 
--- Creating Table Function
---
PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating function [dbo].[fnEvDeadlockGraphGetResourceWaiterList]...'
GO
---
---
CREATE FUNCTION [dbo].[fnEvDeadlockGraphGetResourceWaiterList]
(
	@DeadlockGraph xml
)
RETURNS TABLE
AS
RETURN
(
	---
	--- Get resource list from deadlock graph xml	
	SELECT	t2.resource.value('@id', 'char(50)') [resourceid]
		,	t4.waiter.value('@id', 'char(50)')  [waiterid]
		,	t4.waiter.value('@mode', 'char(5)') [mode]
		,	t4.waiter.value('@requestType', 'varchar(100)') [requestType]
	FROM	@DeadlockGraph.nodes('/deadlock') t(deadlock)
			CROSS APPLY t.deadlock.nodes('./resource-list') t1(resourceList)
			CROSS APPLY t1.resourceList.nodes('./pagelock') t2(resource)
			CROSS APPLY t2.resource.nodes('./waiter-list') t3(waiterList)
			CROSS APPLY t3.waiterList.nodes('./waiter') t4(waiter)
	UNION 
	SELECT	t2.resource.value('@id', 'char(50)') [resourceid]
		,	t4.waiter.value('@id', 'char(50)')  [waiterid]
		,	t4.waiter.value('@mode', 'char(5)') [mode]
		,	t4.waiter.value('@requestType', 'varchar(100)') [requestType]
	FROM	@DeadlockGraph.nodes('/deadlock') t(deadlock)
			CROSS APPLY t.deadlock.nodes('./resource-list') t1(resourceList)
			CROSS APPLY t1.resourceList.nodes('./exchangeEvent') t2(resource)
			CROSS APPLY t2.resource.nodes('./waiter-list') t3(waiterList)
			CROSS APPLY t3.waiterList.nodes('./waiter') t4(waiter)
	UNION
	SELECT	t2.resource.value('@id', 'char(50)') [resourceid]
		,	t4.waiter.value('@id', 'char(50)')  [waiterid]
		,	t4.waiter.value('@mode', 'char(5)') [mode]
		,	t4.waiter.value('@requestType', 'varchar(100)') [requestType]
	FROM	@DeadlockGraph.nodes('/deadlock') t(deadlock)
			CROSS APPLY t.deadlock.nodes('./resource-list') t1(resourceList)
			CROSS APPLY t1.resourceList.nodes('./keylock') t2(resource)
			CROSS APPLY t2.resource.nodes('./waiter-list') t3(waiterList)
			CROSS APPLY t3.waiterList.nodes('./waiter') t4(waiter)
	UNION
	SELECT	t2.resource.value('@id', 'char(50)') [resourceid]
		,	t4.waiter.value('@id', 'char(50)')  [waiterid]
		,	t4.waiter.value('@mode', 'char(5)') [mode]
		,	t4.waiter.value('@requestType', 'varchar(100)') [requestType]
	FROM	@DeadlockGraph.nodes('/deadlock') t(deadlock)
			CROSS APPLY t.deadlock.nodes('./resource-list') t1(resourceList)
			CROSS APPLY t1.resourceList.nodes('./objectlock') t2(resource)
			CROSS APPLY t2.resource.nodes('./waiter-list') t3(waiterList)
			CROSS APPLY t3.waiterList.nodes('./waiter') t4(waiter)
	UNION
	SELECT	t2.resource.value('@id', 'char(50)') [resourceid]
		,	t4.waiter.value('@id', 'char(50)')  [waiterid]
		,	t4.waiter.value('@mode', 'char(5)') [mode]
		,	t4.waiter.value('@requestType', 'varchar(100)') [requestType]
	FROM	@DeadlockGraph.nodes('/deadlock') t(deadlock)
			CROSS APPLY t.deadlock.nodes('./resource-list') t1(resourceList)
			CROSS APPLY t1.resourceList.nodes('./ridlock') t2(resource)
			CROSS APPLY t2.resource.nodes('./waiter-list') t3(waiterList)
			CROSS APPLY t3.waiterList.nodes('./waiter') t4(waiter)
)	
GO
---
---
PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created function [dbo].[fnEvDeadlockGraphGetResourceWaiterList].'
GO

SET NOCOUNT OFF
GO