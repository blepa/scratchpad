USE Monitoring
GO

SET NOCOUNT ON
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--- 
--- Droping Table Function
---
IF EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[dbo].[fnEvDeadlockGraphGetResourceOwnerList]') AND OBJECTPROPERTY(id, 'IsInlineFunction') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Droping function [dbo].[fnEvDeadlockGraphGetResourceOwnerList]...'
	---
	---
	DROP FUNCTION [dbo].[fnEvDeadlockGraphGetResourceOwnerList]
	---
	---
	PRINT '(-)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Droped function [dbo].[fnEvDeadlockGraphGetResourceOwnerList].'
END
GO
--- 
--- Creating Table Function
---
PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating function [dbo].[fnEvDeadlockGraphGetResourceOwnerList]...'
GO
---
---
CREATE FUNCTION [dbo].[fnEvDeadlockGraphGetResourceOwnerList]
(
	@DeadlockGraph xml
)
RETURNS TABLE
AS
RETURN
(
	---
	--- Get resource list from deadlock graph xml	
	SELECT	t2.resource.value('@id', 'char(50)') [resourceid]
		,	t4.owner.value('@id', 'char(50)')  [ownerid]
		,	t4.owner.value('@mode', 'char(5)') [mode]
	FROM	@DeadlockGraph.nodes('/deadlock') t(deadlock)
			CROSS APPLY t.deadlock.nodes('./resource-list') t1(resourceList)
			CROSS APPLY t1.resourceList.nodes('./pagelock') t2(resource)
			CROSS APPLY t2.resource.nodes('./owner-list') t3(ownerList)
			CROSS APPLY t3.ownerList.nodes('./owner') t4(owner)
	UNION 
	SELECT	t2.resource.value('@id', 'char(50)') [resourceid]
		,	t4.owner.value('@id', 'char(50)')  [ownerid]
		,	t4.owner.value('@mode', 'char(5)') [mode]
	FROM	@DeadlockGraph.nodes('/deadlock') t(deadlock)
			CROSS APPLY t.deadlock.nodes('./resource-list') t1(resourceList)
			CROSS APPLY t1.resourceList.nodes('./exchangeEvent') t2(resource)
			CROSS APPLY t2.resource.nodes('./owner-list') t3(ownerList)
			CROSS APPLY t3.ownerList.nodes('./owner') t4(owner)
	UNION
	SELECT	t2.resource.value('@id', 'char(50)') [resourceid]
		,	t4.owner.value('@id', 'char(50)')  [ownerid]
		,	t4.owner.value('@mode', 'char(5)') [mode]
	FROM	@DeadlockGraph.nodes('/deadlock') t(deadlock)
			CROSS APPLY t.deadlock.nodes('./resource-list') t1(resourceList)
			CROSS APPLY t1.resourceList.nodes('./keylock') t2(resource)
			CROSS APPLY t2.resource.nodes('./owner-list') t3(ownerList)
			CROSS APPLY t3.ownerList.nodes('./owner') t4(owner)
	UNION
	SELECT	t2.resource.value('@id', 'char(50)') [resourceid]
		,	t4.owner.value('@id', 'char(50)')  [ownerid]
		,	t4.owner.value('@mode', 'char(5)') [mode]
	FROM	@DeadlockGraph.nodes('/deadlock') t(deadlock)
			CROSS APPLY t.deadlock.nodes('./resource-list') t1(resourceList)
			CROSS APPLY t1.resourceList.nodes('./objectlock') t2(resource)
			CROSS APPLY t2.resource.nodes('./owner-list') t3(ownerList)
			CROSS APPLY t3.ownerList.nodes('./owner') t4(owner)
	UNION
	SELECT	t2.resource.value('@id', 'char(50)') [resourceid]
		,	t4.owner.value('@id', 'char(50)')  [ownerid]
		,	t4.owner.value('@mode', 'char(5)') [mode]
	FROM	@DeadlockGraph.nodes('/deadlock') t(deadlock)
			CROSS APPLY t.deadlock.nodes('./resource-list') t1(resourceList)
			CROSS APPLY t1.resourceList.nodes('./ridlock') t2(resource)
			CROSS APPLY t2.resource.nodes('./owner-list') t3(ownerList)
			CROSS APPLY t3.ownerList.nodes('./owner') t4(owner)
					
)	
GO
---
---
PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created function [dbo].[fnEvDeadlockGraphGetResourceOwnerList].'
GO

SET NOCOUNT OFF
GO