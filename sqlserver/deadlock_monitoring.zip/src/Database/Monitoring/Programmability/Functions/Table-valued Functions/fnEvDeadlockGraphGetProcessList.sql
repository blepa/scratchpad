USE Monitoring
GO

SET NOCOUNT ON
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--- 
--- Droping Table Function
---
IF EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[dbo].[fnEvDeadlockGraphGetProcessList]') AND OBJECTPROPERTY(id, 'IsInlineFunction') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Droping function [dbo].[fnEvDeadlockGraphGetProcessList]...'
	---
	---
	DROP FUNCTION [dbo].[fnEvDeadlockGraphGetProcessList]
	---
	---
	PRINT '(-)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Droped function [dbo].[fnEvDeadlockGraphGetProcessList].'
END
GO
--- 
--- Creating Table Function
---
PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating function [dbo].[fnEvDeadlockGraphGetProcessList]...'
GO
---
---
CREATE FUNCTION [dbo].[fnEvDeadlockGraphGetProcessList]
(
	@DeadlockGraph XML
)
RETURNS TABLE
AS
RETURN
(
	---
	--- Get process list from deadlock graph xml
	WITH processes AS 
	(
	SELECT	t2.process.value('@id', 'char(50)') [id]
		,	t3.inputBuf.value('.', 'varchar(max)') [inputbuf]
		,	t2.process.value('@taskpriority', 'int') [taskpriority]
		,	t2.process.value('@logused', 'int') [logused]
		,	t2.process.value('@waitresource', 'varchar(1000)') [waitresource]
		,	t2.process.value('@waittime', 'bigint') [waittime]
		,	t2.process.value('@ownerId', 'bigint') [ownerId]
		,	t2.process.value('@transactionname', 'varchar(32)') [transactionname]
		,	t2.process.value('@lasttranstarted', 'datetime') [lasttranstarted]
		,	t2.process.value('@XDES', 'varchar(100)') [XDES]
		,	t2.process.value('@lockMode', 'varchar(10)') [lockMode]
		,	t2.process.value('@schedulerid', 'bigint') [schedulerid]
		,	t2.process.value('@kpid', 'bigint') [kpid]
		,	t2.process.value('@status','varchar(100)') [status]
		,	t2.process.value('@spid','smallint') [spid]
		,	t2.process.value('@sbid','bigint') [sbid]
		,	t2.process.value('@ecid','bigint') [ecid]
		,	t2.process.value('@priority','int') [priority]
		,	t2.process.value('@trancount','smallint') [trancount]
		,	t2.process.value('@lastbatchstarted','datetime') [lastbatchstarted]
		,	t2.process.value('@lastbatchcompleted','datetime') [lastbatchcompleted]
		,	t2.process.value('@clientapp','varchar(max)') [clientapp]
		,	t2.process.value('@hostname','varchar(4000)') [hostname]
		,	t2.process.value('@hostpid','bigint') [hostpid]
		,	t2.process.value('@loginname','varchar(1000)') [loginname]
		,	t2.process.value('@isolationlevel','varchar(200)') [isolationlevel]
		,	t2.process.value('@xactid','bigint') [xactid]
		,	t2.process.value('@currentdb','smallint') [currentdb]
		,	t2.process.value('@lockTimeout','varchar(20)') [lockTimeout]
		,	t2.process.value('@clientoption1','varchar(1000)') [clientoption1]
		,	t2.process.value('@clientoption2','varchar(1000)') [clientoption2]
	FROM	@DeadlockGraph.nodes('/deadlock') t(deadlock)
			CROSS APPLY t.deadlock.nodes('./process-list') t1(processList)
			CROSS APPLY t1.processList.nodes('./process') t2(process)			
			OUTER APPLY t2.process.nodes('./inputbuf') t3(inputBuf)	
	)
	,
	victims AS
	(
		SELECT	t2.victimProcess.value('@id', 'varchar(100)') [id]
		FROM	@DeadlockGraph.nodes('/deadlock') t(deadlock)
				CROSS APPLY t.deadlock.nodes('./victim-list') t1(victimList)
				CROSS APPLY t1.victimList.nodes('./victimProcess') t2(victimProcess)
	)

	SELECT	CASE
				WHEN v.id IS NOT NULL THEN 1
				ELSE 0
			END [IsVictim]
	,		p.*
	FROM	processes p
			LEFT JOIN victims v ON p.id = v.id
	
)	
GO
---
---
PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created function [dbo].[fnEvDeadlockGraphGetProcessList].'
GO

SET NOCOUNT OFF
GO
