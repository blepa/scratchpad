USE Monitoring
GO

SET NOCOUNT ON
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--- 
--- Droping Table Function
---
IF EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[dbo].[fnEvDeadlockRaportGetDeadlockGraphs]') AND OBJECTPROPERTY(id, 'IsInlineFunction') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Droping function [dbo].[fnEvDeadlockRaportGetDeadlockGraphs]...'
	---
	---
	DROP FUNCTION [dbo].[fnEvDeadlockRaportGetDeadlockGraphs]
	---
	---
	PRINT '(-)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Droped function [dbo].[fnEvDeadlockRaportGetDeadlockGraphs].'
END
GO
--- 
--- Creating Table Function
---
PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating function [dbo].[fnEvDeadlockRaportGetDeadlockGraphs]...'
GO
---
---
CREATE FUNCTION [dbo].[fnEvDeadlockRaportGetDeadlockGraphs]
(
	@RaportTimestamp DATETIME
)
RETURNS TABLE
AS
RETURN
(
	---
	--- Get deadlock graphs from system_health raports
	SELECT	t1.deadlock.query('./deadlock') [DeadlockGraph]
		,	Deadlock.RaportTimestamp [RaportTimestamp]
		,	DATEADD(MINUTE, DATEDIFF(MINUTE, SYSUTCDATETIME(), SYSDATETIME()), Deadlock.RaportTimestamp) [RaportTimestampLocal]
	FROM	(
				SELECT	CAST(REPLACE(REPLACE(CAST(xed.query('./data/value[1]') as varchar(MAX)),'&lt;','<'), '&gt;', '>') AS XML) AS [XmlVal]
					,	xed.value('@timestamp', 'datetime') [RaportTimestamp]
				FROM	(	SELECT	CAST([target_data] AS XML) AS Target_Data
							FROM    sys.dm_xe_session_targets AS xt
									INNER JOIN sys.dm_xe_sessions AS xs	ON xs.address = xt.event_session_address
							WHERE   xs.name = N'system_health'
									AND xt.target_name = N'ring_buffer'
							
						) XmlData
			CROSS APPLY Target_Data.nodes('RingBufferTarget/event[@name="xml_deadlock_report"]') AS XEventData(xed)	
			) Deadlock
			CROSS
			APPLY	Deadlock.XmlVal.nodes('value') as t1(deadlock)
	WHERE	ISNULL(@RaportTimestamp,'1900-01-01') < 	Deadlock.RaportTimestamp
)	
GO
---
---
PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created function [dbo].[fnEvDeadlockRaportGetDeadlockGraphs].'
GO

SET NOCOUNT OFF
GO
