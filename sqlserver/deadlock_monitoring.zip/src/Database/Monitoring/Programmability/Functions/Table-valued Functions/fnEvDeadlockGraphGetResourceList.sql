USE Monitoring
GO

SET NOCOUNT ON
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--- 
--- Droping Table Function
---
IF EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[dbo].[fnEvDeadlockGraphGetResourceList]') AND OBJECTPROPERTY(id, 'IsInlineFunction') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Droping function [dbo].[fnEvDeadlockGraphGetResourceList]...'
	---
	---
	DROP FUNCTION [dbo].[fnEvDeadlockGraphGetResourceList]
	---
	---
	PRINT '(-)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Droped function [dbo].[fnEvDeadlockGraphGetResourceList].'
END
GO
--- 
--- Creating Table Function
---
PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating function [dbo].[fnEvDeadlockGraphGetResourceList]...'
GO
---
---
CREATE FUNCTION [dbo].[fnEvDeadlockGraphGetResourceList]
(
	@DeadlockGraph xml
)
RETURNS TABLE
AS
RETURN
(
	
	---
	--- Get resource list from deadlock graph xml
	SELECT	CAST('pagelock' AS varchar(20)) [ResourceType]
		,	t2.resource.value('@id', 'char(50)') [resourceid]
		,	t2.resource.value('@fileid', 'int') [fileid]		
		,	t2.resource.value('@pageid', 'bigint') [pageid]
		,	t2.resource.value('@lockPartition', 'int') [lockPartition]
		,	t2.resource.value('@objid', 'int') [objid]		
		,	t2.resource.value('@subresource', 'varchar(100)') [subresource]
		,	t2.resource.value('@hobtid', 'bigint') [hobtid]
		,	t2.resource.value('@dbid', 'smallint') [dbid]
		,	t2.resource.value('@objectname', 'varchar(1000)') [objectname]
		,	t2.resource.value('@indexname', 'sysname') [indexname]		
		,	t2.resource.value('@mode', 'char(5)') [mode]
		,	t2.resource.value('@associatedObjectId', 'bigint') [associatedObjectId]
		,	t2.resource.value('@WaitType', 'nvarchar(60)') [WaitType]
		,	t2.resource.value('@nodeId', 'int') [nodeId]
	FROM	@DeadlockGraph.nodes('/deadlock') t(deadlock)
			CROSS APPLY t.deadlock.nodes('./resource-list') t1(resourceList)
			CROSS APPLY t1.resourceList.nodes('./pagelock') t2(resource)
	UNION 	
	SELECT	CAST('exchangeEvent' AS varchar(20)) [ResourceType]
		,	t2.resource.value('@id', 'char(50)') [resourceid]
		,	t2.resource.value('@fileid', 'int') [fileid]		
		,	t2.resource.value('@pageid', 'bigint') [pageid]
		,	t2.resource.value('@lockPartition', 'int') [lockPartition]
		,	t2.resource.value('@objid', 'int') [objid]		
		,	t2.resource.value('@subresource', 'varchar(100)') [subresource]
		,	t2.resource.value('@hobtid', 'bigint') [hobtid]
		,	t2.resource.value('@dbid', 'smallint') [dbid]
		,	t2.resource.value('@objectname', 'varchar(1000)') [objectname]
		,	t2.resource.value('@indexname', 'sysname') [indexname]		
		,	t2.resource.value('@mode', 'char(5)') [mode]
		,	t2.resource.value('@associatedObjectId', 'bigint') [associatedObjectId]
		,	t2.resource.value('@WaitType', 'nvarchar(60)') [WaitType]
		,	t2.resource.value('@nodeId', 'int') [nodeId]
	FROM	@DeadlockGraph.nodes('/deadlock') t(deadlock)
			CROSS APPLY t.deadlock.nodes('./resource-list') t1(resourceList)
			CROSS APPLY t1.resourceList.nodes('./exchangeEvent') t2(resource)
	UNION
	SELECT	CAST('keylock' AS varchar(20)) [ResourceType]
		,	t2.resource.value('@id', 'char(50)') [resourceid]
		,	t2.resource.value('@fileid', 'int') [fileid]		
		,	t2.resource.value('@pageid', 'bigint') [pageid]
		,	t2.resource.value('@lockPartition', 'int') [lockPartition]
		,	t2.resource.value('@objid', 'int') [objid]		
		,	t2.resource.value('@subresource', 'varchar(100)') [subresource]
		,	t2.resource.value('@hobtid', 'bigint') [hobtid]
		,	t2.resource.value('@dbid', 'smallint') [dbid]
		,	t2.resource.value('@objectname', 'varchar(1000)') [objectname]
		,	t2.resource.value('@indexname', 'sysname') [indexname]		
		,	t2.resource.value('@mode', 'char(5)') [mode]
		,	t2.resource.value('@associatedObjectId', 'bigint') [associatedObjectId]
		,	t2.resource.value('@WaitType', 'nvarchar(60)') [WaitType]
		,	t2.resource.value('@nodeId', 'int') [nodeId]
	FROM	@DeadlockGraph.nodes('/deadlock') t(deadlock)
			CROSS APPLY t.deadlock.nodes('./resource-list') t1(resourceList)
			CROSS APPLY t1.resourceList.nodes('./keylock') t2(resource)
	UNION 	
	SELECT	CAST('objectlock' AS varchar(20)) [ResourceType]
		,	t2.resource.value('@id', 'char(50)') [resourceid]
		,	t2.resource.value('@fileid', 'int') [fileid]		
		,	t2.resource.value('@pageid', 'bigint') [pageid]
		,	t2.resource.value('@lockPartition', 'int') [lockPartition]
		,	t2.resource.value('@objid', 'int') [objid]		
		,	t2.resource.value('@subresource', 'varchar(100)') [subresource]
		,	t2.resource.value('@hobtid', 'bigint') [hobtid]
		,	t2.resource.value('@dbid', 'smallint') [dbid]
		,	t2.resource.value('@objectname', 'varchar(1000)') [objectname]
		,	t2.resource.value('@indexname', 'sysname') [indexname]		
		,	t2.resource.value('@mode', 'char(5)') [mode]
		,	t2.resource.value('@associatedObjectId', 'bigint') [associatedObjectId]
		,	t2.resource.value('@WaitType', 'nvarchar(60)') [WaitType]
		,	t2.resource.value('@nodeId', 'int') [nodeId]
	FROM	@DeadlockGraph.nodes('/deadlock') t(deadlock)
			CROSS APPLY t.deadlock.nodes('./resource-list') t1(resourceList)
			CROSS APPLY t1.resourceList.nodes('./objectlock') t2(resource)
	UNION
	SELECT	CAST('ridlock' AS varchar(20)) [ResourceType]
		,	t2.resource.value('@id', 'char(50)') [resourceid]
		,	t2.resource.value('@fileid', 'int') [fileid]		
		,	t2.resource.value('@pageid', 'bigint') [pageid]
		,	t2.resource.value('@lockPartition', 'int') [lockPartition]
		,	t2.resource.value('@objid', 'int') [objid]		
		,	t2.resource.value('@subresource', 'varchar(100)') [subresource]
		,	t2.resource.value('@hobtid', 'bigint') [hobtid]
		,	t2.resource.value('@dbid', 'smallint') [dbid]
		,	t2.resource.value('@objectname', 'varchar(1000)') [objectname]
		,	t2.resource.value('@indexname', 'sysname') [indexname]		
		,	t2.resource.value('@mode', 'char(5)') [mode]
		,	t2.resource.value('@associatedObjectId', 'bigint') [associatedObjectId]
		,	t2.resource.value('@WaitType', 'nvarchar(60)') [WaitType]
		,	t2.resource.value('@nodeId', 'int') [nodeId]
	FROM	@DeadlockGraph.nodes('/deadlock') t(deadlock)
			CROSS APPLY t.deadlock.nodes('./resource-list') t1(resourceList)
			CROSS APPLY t1.resourceList.nodes('./ridlock') t2(resource)
	

					
)	
GO
---
---
PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created function [dbo].[fnEvDeadlockGraphGetResourceList].'
GO

SET NOCOUNT OFF
GO