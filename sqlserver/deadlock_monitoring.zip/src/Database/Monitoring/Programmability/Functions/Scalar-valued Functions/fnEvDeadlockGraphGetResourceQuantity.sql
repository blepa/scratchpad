USE Monitoring
GO

SET NOCOUNT ON
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--- 
--- Droping Table Function
---
IF EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[dbo].[fnEvDeadlockGraphGetResourceQuantity]') AND OBJECTPROPERTY(id, 'IsScalarFunction') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Droping function [dbo].[fnEvDeadlockGraphGetResourceQuantity]...'
	---
	---
	DROP FUNCTION [dbo].[fnEvDeadlockGraphGetResourceQuantity]
	---
	---
	PRINT '(-)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Droped function [dbo].[fnEvDeadlockGraphGetResourceQuantity].'
END
GO
--- 
--- Creating Table Function
---
PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating function [dbo].[fnEvDeadlockGraphGetResourceQuantity]...'
GO
---
---
CREATE FUNCTION [dbo].[fnEvDeadlockGraphGetResourceQuantity]
(
	@DeadlockGraph xml
)
RETURNS SMALLINT
AS
BEGIN
	RETURN	(	(SELECT @DeadlockGraph.value('count(/deadlock/resource-list/keylock)', 'smallint')) +
				(SELECT @DeadlockGraph.value('count(/deadlock/resource-list/exchangeEvent)', 'smallint')) +
				(SELECT @DeadlockGraph.value('count(/deadlock/resource-list/pagelock)', 'smallint')) +
				(SELECT @DeadlockGraph.value('count(/deadlock/resource-list/objectlock)', 'smallint')) +
				(SELECT @DeadlockGraph.value('count(/deadlock/resource-list/ridlock)', 'smallint'))
			)
END
GO
---
---
PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created function [dbo].[fnEvDeadlockGraphGetResourceQuantity].'
GO

SET NOCOUNT OFF
GO
