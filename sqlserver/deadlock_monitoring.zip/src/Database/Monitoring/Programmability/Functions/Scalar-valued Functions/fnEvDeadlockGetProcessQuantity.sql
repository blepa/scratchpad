USE Monitoring
GO

SET NOCOUNT ON
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--- 
--- Droping Table Function
---
IF EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[dbo].[fnEvDeadlockGetProcessQuantity]') AND OBJECTPROPERTY(id, 'IsScalarFunction') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Droping function [dbo].[fnEvDeadlockGetProcessQuantity]...'
	---
	---
	DROP FUNCTION [dbo].[fnEvDeadlockGetProcessQuantity]
	---
	---
	PRINT '(-)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Droped function [dbo].[fnEvDeadlockGetProcessQuantity].'
END
GO
--- 
--- Creating Table Function
---
PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating function [dbo].[fnEvDeadlockGetProcessQuantity]...'
GO
---
---
CREATE FUNCTION [dbo].[fnEvDeadlockGetProcessQuantity]
(
	@DeadlockID bigint
)
RETURNS SMALLINT
AS
BEGIN
	RETURN	(	SELECT	COUNT(1)
				FROM	dbo.EV_DEADLOCK_PROCESS_LIST PL WITH(NOLOCK)
				WHERE	PL.DeadlockID = @DeadlockID
	
			)
END
GO
---
---
PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created function [dbo].[fnEvDeadlockGetProcessQuantity].'
GO

SET NOCOUNT OFF
GO