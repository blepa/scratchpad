USE Monitoring
GO

SET NOCOUNT ON
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--- 
--- Droping Table Function
---
IF EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[dbo].[fnEvDeadlockGraphGetExecutionStackQuantity]') AND OBJECTPROPERTY(id, 'IsScalarFunction') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Droping function [dbo].[fnEvDeadlockGraphGetExecutionStackQuantity]...'
	---
	---
	DROP FUNCTION [dbo].[fnEvDeadlockGraphGetExecutionStackQuantity]
	---
	---
	PRINT '(-)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Droped function [dbo].[fnEvDeadlockGraphGetExecutionStackQuantity].'
END
GO
--- 
--- Creating Table Function
---
PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating function [dbo].[fnEvDeadlockGraphGetExecutionStackQuantity]...'
GO
---
---
CREATE FUNCTION [dbo].[fnEvDeadlockGraphGetExecutionStackQuantity]
(
	@DeadlockGraph xml
)
RETURNS SMALLINT
AS
BEGIN
	RETURN ( SELECT @DeadlockGraph.value('count(/deadlock/process-list/process/executionStack/frame)', 'smallint') )
END
GO
---
---
PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created function [dbo].[fnEvDeadlockGraphGetExecutionStackQuantity].'
GO

SET NOCOUNT OFF
GO
