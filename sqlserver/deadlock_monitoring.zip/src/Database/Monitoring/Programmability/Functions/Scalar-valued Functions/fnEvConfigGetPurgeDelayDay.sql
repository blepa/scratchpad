USE Monitoring
GO

SET NOCOUNT ON
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--- 
--- Droping Table Function
---
IF EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[dbo].[fnEvConfigGetPurgeDelayDay]') AND OBJECTPROPERTY(id, 'IsScalarFunction') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Droping function [dbo].[fnEvConfigGetPurgeDelayDay]...'
	---
	---
	DROP FUNCTION [dbo].[fnEvConfigGetPurgeDelayDay]
	---
	---
	PRINT '(-)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Droped function [dbo].[fnEvConfigGetPurgeDelayDay].'
END
GO
--- 
--- Creating Table Function
---
PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating function [dbo].[fnEvConfigGetPurgeDelayDay]...'
GO
---
---
CREATE FUNCTION [dbo].[fnEvConfigGetPurgeDelayDay]
(
	@PurgeDelayDay INT = NULL
)
RETURNS INT
AS
BEGIN
	RETURN	(	SELECT	CASE
							WHEN @PurgeDelayDay IS NOT NULL THEN @PurgeDelayDay
							WHEN @PurgeDelayDay IS NULL AND ISNUMERIC(dbo.fnEvConfigValue('PURGE_DELAY_DAY')) = 1 THEN dbo.fnEvConfigValue('PURGE_DELAY_DAY')
							ELSE 14 /* defualt */
						END
				
			)
END
GO
---
---
PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created function [dbo].[fnEvConfigGetPurgeDelayDay].'
GO

SET NOCOUNT OFF
GO
