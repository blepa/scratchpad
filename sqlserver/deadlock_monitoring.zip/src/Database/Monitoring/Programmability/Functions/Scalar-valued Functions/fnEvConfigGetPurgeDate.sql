USE Monitoring
GO

SET NOCOUNT ON
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--- 
--- Droping Table Function
---
IF EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[dbo].[fnEvConfigGetPurgeDate]') AND OBJECTPROPERTY(id, 'IsScalarFunction') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Droping function [dbo].[fnEvConfigGetPurgeDate]...'
	---
	---
	DROP FUNCTION [dbo].[fnEvConfigGetPurgeDate]
	---
	---
	PRINT '(-)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Droped function [dbo].[fnEvConfigGetPurgeDate].'
END
GO
--- 
--- Creating Table Function
---
PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating function [dbo].[fnEvConfigGetPurgeDate]...'
GO
---
---
CREATE FUNCTION [dbo].[fnEvConfigGetPurgeDate]
(
	@PurgeReferenceDate DATETIME
,	@PurgeDelayDay INT
)
RETURNS DATETIME
AS
BEGIN
	RETURN	(	SELECT	DATEADD(DAY, ( @PurgeDelayDay * -1 ) + 1, CAST( CONVERT(VARCHAR(10), ISNULL(@PurgeReferenceDate,GETDATE()), 121) AS DATETIME ))					
			)
END
GO
---
---
PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created function [dbo].[fnEvConfigGetPurgeDate].'
GO

SET NOCOUNT OFF
GO



 