USE Monitoring
GO

SET NOCOUNT ON
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--- 
--- Droping Table Function
---
IF EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[dbo].[fnEvDeadlockGraphGetProcessQuantity]') AND OBJECTPROPERTY(id, 'IsScalarFunction') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Droping function [dbo].[fnEvDeadlockGraphGetProcessQuantity]...'
	---
	---
	DROP FUNCTION [dbo].[fnEvDeadlockGraphGetProcessQuantity]
	---
	---
	PRINT '(-)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Droped function [dbo].[fnEvDeadlockGraphGetProcessQuantity].'
END
GO
--- 
--- Creating Table Function
---
PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating function [dbo].[fnEvDeadlockGraphGetProcessQuantity]...'
GO
---
---
CREATE FUNCTION [dbo].[fnEvDeadlockGraphGetProcessQuantity]
(
	@DeadlockGraph xml
)
RETURNS SMALLINT
AS
BEGIN
	RETURN ( SELECT @DeadlockGraph.value('count(/deadlock/process-list/process)', 'smallint') )
END
GO
---
---
PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created function [dbo].[fnEvDeadlockGraphGetProcessQuantity].'
GO

SET NOCOUNT OFF
GO
