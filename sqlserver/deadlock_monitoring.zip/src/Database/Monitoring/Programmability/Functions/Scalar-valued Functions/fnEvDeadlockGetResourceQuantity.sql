USE Monitoring
GO

SET NOCOUNT ON
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--- 
--- Droping Table Function
---
IF EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID('[dbo].[fnEvDeadlockGetResourceQuantity]') AND OBJECTPROPERTY(id, 'IsScalarFunction') = 1) 
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Droping function [dbo].[fnEvDeadlockGetResourceQuantity]...'
	---
	---
	DROP FUNCTION [dbo].[fnEvDeadlockGetResourceQuantity]
	---
	---
	PRINT '(-)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Droped function [dbo].[fnEvDeadlockGetResourceQuantity].'
END
GO
--- 
--- Creating Table Function
---
PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Creating function [dbo].[fnEvDeadlockGetResourceQuantity]...'
GO
---
---
CREATE FUNCTION [dbo].[fnEvDeadlockGetResourceQuantity]
(
	@DeadlockID bigint
)
RETURNS SMALLINT
AS
BEGIN
	RETURN	(	SELECT	COUNT(1)
				FROM	dbo.EV_DEADLOCK_RESOURCE_LIST RL WITH(NOLOCK)
				WHERE	RL.DeadlockID = @DeadlockID
			)
END
GO
---
---
PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Created function [dbo].[fnEvDeadlockGetResourceQuantity].'
GO

SET NOCOUNT OFF
GO