USE Monitoring
GO

SET NOCOUNT ON
GO
IF NOT EXISTS	( SELECT 1 FROM [dbo].[EV_CONFIG] EV WHERE EV.ConfigID = 1 )
BEGIN
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Adding [(1)PURGE_DELAY_DAY] to [dbo].[EV_CONFIG]...'
	---
	---
	INSERT INTO [dbo].[EV_CONFIG]
	(
		ConfigID
	,	ConfigKey
	,	ConfigValue
	,	CreationUser
	)
	SELECT	1
		,	'PURGE_DELAY_DAY'
		,	'14'
		,	'X160245'
	WHERE	NOT EXISTS	( SELECT 1 FROM [dbo].[EV_CONFIG] EV WHERE EV.ConfigID = 1 )
	---
	---
	PRINT '(+)    ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Added [(1)PURGE_DELAY_DAY] to [dbo].[EV_CONFIG].'
END
ELSE
	PRINT 'Info:  ' + CONVERT(VARCHAR(23),GETDATE(), 121) + ' ' + @@SERVERNAME + '.' + DB_NAME() +  ' - Exists [(1)PURGE_DELAY_DAY] in [dbo].[EV_CONFIG].'
GO
					
SET NOCOUNT OFF
GO
